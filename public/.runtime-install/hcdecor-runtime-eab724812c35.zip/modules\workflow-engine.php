<?php
if (!defined('ABSPATH')) exit;

/* HCDecor production workflow engine: queue claim -> process -> review -> approve -> publish web. */

function hcdecor_workflow_time($value){$raw=is_scalar($value)?(string)$value:'';if($raw===''||strlen($raw)>64)return 0;return strtotime($raw)?:0;}

function hcdecor_workflow_log_entries($value){
    if(!is_array($value)) return [];$out=[];
    foreach(array_slice($value,-100) as $row){if(!is_array($row))continue;$out[]=['time'=>hcdecor_workflow_clip($row['time']??'',64),'event'=>sanitize_key(hcdecor_workflow_clip($row['event']??'',100)),'note'=>hcdecor_workflow_clip($row['note']??'',500),'user'=>max(0,(int)($row['user']??0))];}
    return $out;
}
function hcdecor_workflow_log($job_id,$event,$note=''){
    $log=hcdecor_workflow_log_entries(get_post_meta($job_id,'hc_workflow_log',true));
    $log[]=[
        'time'=>current_time('mysql'),
        'event'=>sanitize_key($event),
        'note'=>function_exists('mb_substr')?mb_substr(sanitize_text_field($note),0,500):substr(sanitize_text_field($note),0,500),
        'user'=>get_current_user_id()
    ];
    if(count($log)>100) $log=array_slice($log,-100);
    update_post_meta($job_id,'hc_workflow_log',$log);
}

function hcdecor_workflow_set_status($job_id,$status,$note=''){
    $job_id=(int)$job_id;
    if(!$job_id || get_post_type($job_id)!=='hc_content_job') return false;
    $allowed=['draft','processing','review','approved','published_web','failed'];
    if(!in_array($status,$allowed,true)) return false;
    $old=hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_status',true),50);
    if($old===$status) return true;
    if($old==='' && $status!=='draft') return false;
    $transitions=[
        ''=>['draft'],
        'draft'=>['processing'],
        'processing'=>['review','failed'],
        'review'=>['approved','draft'],
        'approved'=>['published_web'],
        'published_web'=>['approved'],
        'failed'=>['draft']
    ];
    if(!in_array($status,(array)($transitions[$old]??[]),true)) return false;
    if($old===''){
        if(!add_post_meta($job_id,'hc_agent_status',$status,true)) return false;
    }elseif(!update_post_meta($job_id,'hc_agent_status',$status,$old)){
        return false;
    }
    update_post_meta($job_id,'hc_status_changed_at',current_time('mysql'));
    if($status==='review') update_post_meta($job_id,'hc_review_entered_at',current_time('mysql'));
    elseif($old==='review') delete_post_meta($job_id,'hc_review_entered_at');
    hcdecor_workflow_log($job_id,$status,$note?:($old.' → '.$status));
    do_action('hcdecor_workflow_status_changed',$job_id,$old,$status);
    return true;
}

function hcdecor_workflow_sweep_mutex_acquire(){
    $key='hcdecor_worker_mutex_sweep_mutex'; $now=time();
    $raw=get_option($key,[]);
    $held=is_array($raw)?$raw:[];
    $held_at=is_array($raw)?(int)($raw['at']??0):(int)$raw;
    $invalid_array=is_array($raw) && $raw && (empty($raw['token']) || !$held_at);
    if($invalid_array){
        if(!hcdecor_workflow_claim_mutex_delete_if_same($key,$raw)) return false;
        $raw=[]; $held=[]; $held_at=0;
    }
    if($held_at>=($now-30)) return false;
    if($raw!==false && $raw!==[] && $raw!=='' && !hcdecor_workflow_claim_mutex_delete_if_same($key,$raw)) return false;
    $owned=['token'=>wp_generate_uuid4(),'at'=>$now];
    return add_option($key,$owned,'','no')?$owned:false;
}

function hcdecor_workflow_sweep_mutex_release($owned){
    return is_array($owned) && !empty($owned['token'])?hcdecor_workflow_claim_mutex_delete_if_same('hcdecor_worker_mutex_sweep_mutex',$owned):false;
}

function hcdecor_workflow_sweep_claim_mutexes($limit=100){
    global $wpdb;
    $owned=hcdecor_workflow_sweep_mutex_acquire();
    if(!$owned){
        $next=wp_next_scheduled('hcdecor_worker_mutex_sweep_tick');
        if(!$next || $next<(time()-60)){
            if($next) wp_clear_scheduled_hook('hcdecor_worker_mutex_sweep_tick');
            wp_schedule_single_event(time()+15,'hcdecor_worker_mutex_sweep_tick');
        }
        return ['stale'=>0,'deleted'=>0,'limited'=>false,'busy'=>true];
    }
    $limit=max(1,min(100,(int)$limit));
    $cutoff=time()-120;
    $last_raw=get_option('hcdecor_worker_mutex_sweep_last',[]);$last=is_array($last_raw)?$last_raw:[];
    $cursor=max(0,(int)($last['cursor']??0));
    $claim_like=$wpdb->esc_like('hcdecor_claim_mutex_').'%';
    $lifecycle_like=$wpdb->esc_like('hcdecor_lifecycle_mutex_').'%';
    $rows=$wpdb->get_results($wpdb->prepare("SELECT option_id,option_name FROM {$wpdb->options} WHERE (option_name LIKE %s OR option_name LIKE %s) AND option_id>%d ORDER BY option_id ASC LIMIT %d",$claim_like,$lifecycle_like,$cursor,$limit+1));
    $wrapped=false;
    if(!$rows && $cursor>0){
        $cursor=0;
        $wrapped=true;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT option_id,option_name FROM {$wpdb->options} WHERE (option_name LIKE %s OR option_name LIKE %s) ORDER BY option_id ASC LIMIT %d",$claim_like,$lifecycle_like,$limit+1));
    }
    $limited=count($rows)>$limit;
    $rows=array_slice((array)$rows,0,$limit);
    $stale=0; $deleted=0; $lifecycle_scanned=0; $next_cursor=$cursor;
    foreach($rows as $row){
        $next_cursor=max($next_cursor,(int)$row->option_id);
        $name=(string)$row->option_name;
        if(strpos($name,'hcdecor_lifecycle_mutex_')===0) $lifecycle_scanned++;
        $observed=get_option($name,[]);
        $mutex=is_array($observed)?$observed:[];
        $mutex_at=is_array($observed)?(int)($mutex['at']??0):(int)$observed;
        if(!$mutex_at || $mutex_at<$cutoff){
            $stale++;
            if(hcdecor_workflow_claim_mutex_delete_if_same($name,$observed)) $deleted++;
        }
    }
    $more_after=$limited || (!$wrapped && $next_cursor>0 && (bool)$wpdb->get_var($wpdb->prepare("SELECT option_id FROM {$wpdb->options} WHERE (option_name LIKE %s OR option_name LIKE %s) AND option_id>%d ORDER BY option_id ASC LIMIT 1",$claim_like,$lifecycle_like,$next_cursor)));
    $continue=$more_after;
    if($wrapped && !$limited) $continue=false;
    $stored_cursor=$continue?$next_cursor:0;
    update_option('hcdecor_worker_mutex_sweep_last',[
        'at'=>current_time('mysql'),'ts'=>time(),'scanned'=>count($rows),'lifecycle_scanned'=>$lifecycle_scanned,'stale'=>$stale,'deleted'=>$deleted,'limited'=>$continue,'cursor'=>$stored_cursor,'wrapped'=>$wrapped
    ],false);
    $next=wp_next_scheduled('hcdecor_worker_mutex_sweep_tick');
    if($continue){
        if(!$next || $next<(time()-60) || $next>(time()+120)){
            if($next) wp_clear_scheduled_hook('hcdecor_worker_mutex_sweep_tick');
            wp_schedule_single_event(time()+30,'hcdecor_worker_mutex_sweep_tick');
        }
    }elseif($next) wp_clear_scheduled_hook('hcdecor_worker_mutex_sweep_tick');
    $released=hcdecor_workflow_sweep_mutex_release($owned);
    if(!$released){
        $current=get_option('hcdecor_worker_mutex_sweep_mutex',[]);
        $current_token=is_array($current)&&is_scalar($current['token']??'')?(string)$current['token']:'';
        $owned_token=is_array($owned)&&is_scalar($owned['token']??'')?(string)$owned['token']:'';if($current_token!=='' && $owned_token!=='' && hash_equals($owned_token,$current_token)) hcdecor_workflow_claim_mutex_delete_if_same('hcdecor_worker_mutex_sweep_mutex',$current);
        $retry=wp_next_scheduled('hcdecor_worker_mutex_sweep_tick');
        if(!$retry || $retry<(time()-60)){
            if($retry) wp_clear_scheduled_hook('hcdecor_worker_mutex_sweep_tick');
            wp_schedule_single_event(time()+15,'hcdecor_worker_mutex_sweep_tick');
        }
    }
    return ['stale'=>$stale,'deleted'=>$deleted,'limited'=>$continue,'busy'=>false,'released'=>$released];
}

add_action('init',function(){
    $last_raw=get_option('hcdecor_worker_mutex_sweep_last',[]);$last=is_array($last_raw)?$last_raw:[];
    $last_ts=(int)($last['ts']??0);
    if(!$last_ts && !empty($last['at'])) $last_ts=hcdecor_workflow_time($last['at']);
    if($last_ts && $last_ts>=time()-30) return;
    $next=wp_next_scheduled('hcdecor_worker_mutex_sweep_tick');
    if($next && $next>=(time()-60)) return;
    if($next) wp_clear_scheduled_hook('hcdecor_worker_mutex_sweep_tick');
    hcdecor_workflow_sweep_claim_mutexes(100);
},60);
add_action('hcdecor_worker_mutex_sweep_tick',function(){ hcdecor_workflow_sweep_claim_mutexes(100); });

function hcdecor_workflow_claim_mutex_delete_if_same($key,$observed){
    global $wpdb;
    $key=(string)$key;
    if($key==='' || !$observed) return false;
    $serialized=maybe_serialize($observed);
    $deleted=$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$key,$serialized));
    if($deleted){
        wp_cache_delete($key,'options');
        wp_cache_delete('alloptions','options');
    }
    return $deleted===1;
}

function hcdecor_workflow_clear_worker_claim($job_id,$clear_claimed=true,$clear_mutex=false){
    $job_id=(int)$job_id;
    delete_post_meta($job_id,'hc_agent_lock_until');
    delete_post_meta($job_id,'hc_agent_claim_token');
    delete_post_meta($job_id,'hc_agent_heartbeat');
    if($clear_claimed) delete_post_meta($job_id,'hc_agent_claimed_at');
    if($clear_mutex){
        $key='hcdecor_claim_mutex_'.$job_id;
        $observed=get_option($key,[]);
        $mutex_at=is_array($observed)?(int)($observed['at']??0):(int)$observed;
        if($observed && (!$mutex_at || $mutex_at<(time()-120))) hcdecor_workflow_claim_mutex_delete_if_same($key,$observed);
    }
}

function hcdecor_workflow_claim_mutex_release($job_id,$claim_token){
    $key='hcdecor_claim_mutex_'.(int)$job_id;
    $mutex_raw=get_option($key,[]);$mutex=is_array($mutex_raw)?$mutex_raw:[];
    $mutex_token=is_scalar($mutex['token']??'')?(string)$mutex['token']:'';if($claim_token==='' || $mutex_token!==$claim_token) return false;
    return hcdecor_workflow_claim_mutex_delete_if_same($key,$mutex);
}

function hcdecor_workflow_clear_owned_claim($job_id,$claim_token,$clear_claimed=true){
    $job_id=(int)$job_id;
    if($claim_token==='' || hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_claim_token',true),128)!==$claim_token) return false;
    hcdecor_workflow_clear_worker_claim($job_id,$clear_claimed,false);
    hcdecor_workflow_claim_mutex_release($job_id,$claim_token);
    return true;
}

function hcdecor_workflow_finalize_claim($job_id,$claim_token,$now,$message='Agent claimed job'){
    $job_id=(int)$job_id;
    if($claim_token==='' || hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_claim_token',true),128)!==$claim_token) return false;
    if(hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_status',true),50)!=='draft'){
        hcdecor_workflow_clear_owned_claim($job_id,$claim_token,true);
        return false;
    }
    update_post_meta($job_id,'hc_agent_claimed_at',current_time('mysql'));
    update_post_meta($job_id,'hc_agent_lock_until',(int)$now+600);
    if(hcdecor_workflow_set_status($job_id,'processing',$message)) return true;
    hcdecor_workflow_clear_owned_claim($job_id,$claim_token,true);
    return false;
}

function hcdecor_workflow_refresh_owned_claim($job_id,$claim_token,$seconds=600){
    $job_id=(int)$job_id;
    if($claim_token==='' || hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_claim_token',true),128)!==$claim_token) return false;
    if(hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_status',true),50)!=='processing') return false;
    $lock=(int)get_post_meta($job_id,'hc_agent_lock_until',true);
    if($lock<=0 || $lock<time()) return false;
    $new_lock=time()+max(60,(int)$seconds);
    update_post_meta($job_id,'hc_agent_lock_until',$new_lock);
    if(hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_claim_token',true),128)!==$claim_token || hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_status',true),50)!=='processing'){
        if(hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_claim_token',true),128)===$claim_token && (int)get_post_meta($job_id,'hc_agent_lock_until',true)===$new_lock) delete_post_meta($job_id,'hc_agent_lock_until');
        return false;
    }
    update_post_meta($job_id,'hc_agent_heartbeat',current_time('mysql'));
    return true;
}

function hcdecor_workflow_owned_claim_active($job_id,$claim_token){
    $job_id=(int)$job_id;
    if($claim_token==='' || hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_claim_token',true),128)!==$claim_token) return false;
    if(hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_status',true),50)!=='processing') return false;
    $lock=(int)get_post_meta($job_id,'hc_agent_lock_until',true);
    return $lock>0 && $lock>=time();
}

function hcdecor_workflow_finish_owned_claim($job_id,$claim_token,$status,$note=''){
    $job_id=(int)$job_id;
    if(!hcdecor_workflow_owned_claim_active($job_id,$claim_token)) return false;
    if(!hcdecor_workflow_set_status($job_id,$status,$note)) return false;
    if(!hcdecor_workflow_clear_owned_claim($job_id,$claim_token,true)){
        hcdecor_workflow_log($job_id,$status,'Worker claim cleanup lost ownership after status finalization');
        return true;
    }
    return true;
}

function hcdecor_workflow_lifecycle_mutex_acquire($job_id,$claim_token,$ttl=30){
    $job_id=(int)$job_id; $claim_token=(string)$claim_token;
    if(!$job_id || $claim_token==='') return false;
    $key='hcdecor_lifecycle_mutex_'.$job_id; $now=time(); $ttl=max(5,min(120,(int)$ttl));
    $held_raw=get_option($key,[]);
    $held=is_array($held_raw)?$held_raw:[];
    $held_at=(int)($held['at']??0);
    $invalid=is_array($held_raw) && $held_raw && (empty($held['token']) || empty($held['claim_token']) || !$held_at);
    if($invalid){
        if(!hcdecor_workflow_claim_mutex_delete_if_same($key,$held_raw)) return false;
        $held_raw=[]; $held=[]; $held_at=0;
    }
    if($held_at && $held_at>=($now-$ttl)) return false;
    if($held_raw!==false && $held_raw!==[] && $held_raw!=='' && !hcdecor_workflow_claim_mutex_delete_if_same($key,$held_raw)) return false;
    $owned=['token'=>wp_generate_uuid4(),'claim_token'=>$claim_token,'at'=>$now];
    return add_option($key,$owned,'','no')?$owned:false;
}

function hcdecor_workflow_lifecycle_mutex_release($job_id,$owned){
    $key='hcdecor_lifecycle_mutex_'.(int)$job_id;
    return is_array($owned) && !empty($owned['token'])?hcdecor_workflow_claim_mutex_delete_if_same($key,$owned):false;
}

function hcdecor_workflow_claim_response($job,$claim_token){
    $channels_raw=get_post_meta($job->ID,'hc_channels',true);$channels=array_values(array_intersect(['web','facebook','tiktok','youtube'],is_array($channels_raw)?$channels_raw:[]));
    $media_raw=get_post_meta($job->ID,'hc_media_ids',true);$media_ids=function_exists('hcdecor_ops_valid_media_ids')?hcdecor_ops_valid_media_ids($media_raw):array_slice(array_values(array_filter(array_map('intval',is_array($media_raw)?$media_raw:[]))),0,60);
    $title=function_exists('hcdecor_ops_limit_text')?hcdecor_ops_limit_text($job->post_title,500):substr((string)$job->post_title,0,500);
    $brief=function_exists('hcdecor_ops_limit_text')?hcdecor_ops_limit_text($job->post_content,20000):substr((string)$job->post_content,0,20000);
    return rest_ensure_response([
        'id'=>$job->ID,'title'=>$title,'brief'=>$brief,
        'project_id'=>(int)get_post_meta($job->ID,'hc_project_id',true),
        'channels'=>$channels,
        'media_ids'=>$media_ids,
        'cover_id'=>(int)get_post_meta($job->ID,'hc_cover_id',true),
        'status'=>'processing','claim_token'=>$claim_token,'outbound'=>false
    ]);
}

function hcdecor_workflow_recover_orphan_draft_claims($limit=20){
    $jobs=get_posts([
        'post_type'=>'hc_content_job','post_status'=>'publish','numberposts'=>max(1,min(50,(int)$limit)),'fields'=>'ids',
        'meta_query'=>[
            'relation'=>'AND',
            ['key'=>'hc_agent_status','value'=>'draft'],
            ['key'=>'hc_agent_claim_token','compare'=>'EXISTS']
        ],
        'orderby'=>'modified','order'=>'ASC'
    ]);
    $now=time(); $recovered=0;
    foreach($jobs as $job_id){
        $token=hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_claim_token',true),128);
        if($token==='') continue;
        $lock=(int)get_post_meta($job_id,'hc_agent_lock_until',true);
        if($lock>$now) continue;
        $mutex_raw=get_option('hcdecor_claim_mutex_'.$job_id,[]);$mutex=is_array($mutex_raw)?$mutex_raw:[];
        if(!empty($mutex['at']) && (int)$mutex['at']>=($now-120)) continue;
        $claimed=hcdecor_workflow_time(get_post_meta($job_id,'hc_agent_claimed_at',true));
        $modified=hcdecor_workflow_time(get_post_field('post_modified',$job_id));
        $age_base=$claimed?:$modified;
        $stale_after=$claimed?120:900;
        if(!$age_base || $age_base>=($now-$stale_after)) continue;
        $lifecycle=hcdecor_workflow_lifecycle_mutex_acquire($job_id,$token,30);
        if(!$lifecycle) continue;
        if(hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_status',true),50)!=='draft' || hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_claim_token',true),128)!==$token){
            hcdecor_workflow_lifecycle_mutex_release($job_id,$lifecycle);
            continue;
        }
        hcdecor_workflow_clear_worker_claim($job_id,true,false);
        hcdecor_workflow_claim_mutex_release($job_id,$token);
        hcdecor_workflow_lifecycle_mutex_release($job_id,$lifecycle);
        update_post_meta($job_id,'hc_agent_recovered_at',current_time('mysql'));
        update_post_meta($job_id,'hc_agent_recovery_reason','orphan_draft_claim');
        hcdecor_workflow_log($job_id,'draft','Recovered orphan worker claim');
        $recovered++;
    }
    return $recovered;
}

add_action('rest_api_init',function(){
    register_rest_route('hcdecor/v1','/operations/claim',[
        'methods'=>'POST',
        'permission_callback'=>'hcdecor_ops_bridge_auth',
        'callback'=>function(WP_REST_Request $r){
            if(!function_exists('hcdecor_ai_worker_enabled') || !hcdecor_ai_worker_enabled()) return new WP_Error('worker_disabled','AI Worker is disabled',['status'=>503]);
            $now=time();
            hcdecor_workflow_recover_orphan_draft_claims(50);
            $jobs=get_posts([
                'post_type'=>'hc_content_job','post_status'=>'publish','numberposts'=>50,
                'orderby'=>'date','order'=>'ASC',
                'meta_query'=>[['key'=>'hc_agent_status','value'=>'draft']]
            ]);
            foreach($jobs as $j){
                $lock=(int)get_post_meta($j->ID,'hc_agent_lock_until',true);
                if($lock>$now) continue;
                $claim_token=wp_generate_uuid4();
                $mutex='hcdecor_claim_mutex_'.$j->ID;
                if(!add_option($mutex,['token'=>$claim_token,'at'=>$now],'',false)){
                    $existing=get_option($mutex,[]);
                    $existing_at=is_array($existing)?(int)($existing['at']??0):(int)$existing;
                    if($existing && (!$existing_at || $existing_at<($now-120))){
                        if(!hcdecor_workflow_claim_mutex_delete_if_same($mutex,$existing)) continue;
                        if(!add_option($mutex,['token'=>$claim_token,'at'=>$now],'',false)) continue;
                    }else continue;
                }
                if(hcdecor_workflow_clip(get_post_meta($j->ID,'hc_agent_status',true),50)!=='draft'){
                    hcdecor_workflow_claim_mutex_release($j->ID,$claim_token);
                    continue;
                }
                if((int)get_post_meta($j->ID,'hc_agent_lock_until',true)>$now){
                    hcdecor_workflow_claim_mutex_release($j->ID,$claim_token);
                    continue;
                }
                if(!add_post_meta($j->ID,'hc_agent_claim_token',$claim_token,true)){
                    $existing_token=hcdecor_workflow_clip(get_post_meta($j->ID,'hc_agent_claim_token',true),128);
                    $existing_lock=(int)get_post_meta($j->ID,'hc_agent_lock_until',true);
                    if($existing_token!=='' && $existing_lock<=$now){
                        $claimed_raw=get_post_meta($j->ID,'hc_agent_claimed_at',true);$claimed_raw=is_scalar($claimed_raw)?(string)$claimed_raw:'';
                        $claimed=hcdecor_workflow_time($claimed_raw);
                        if($claimed && $claimed<($now-120)){
                            $lifecycle=hcdecor_workflow_lifecycle_mutex_acquire($j->ID,$existing_token,30);
                            if($lifecycle){
                                $still_orphan=hcdecor_workflow_clip(get_post_meta($j->ID,'hc_agent_status',true),50)==='draft'
                                    && hcdecor_workflow_clip(get_post_meta($j->ID,'hc_agent_claim_token',true),128)===$existing_token
                                    && (int)get_post_meta($j->ID,'hc_agent_lock_until',true)<=$now;
                                if($still_orphan){
                                    hcdecor_workflow_clear_worker_claim($j->ID,true,false);
                                    update_post_meta($j->ID,'hc_agent_recovered_at',current_time('mysql'));
                                    update_post_meta($j->ID,'hc_agent_recovery_reason','orphan_draft_claim');
                                    hcdecor_workflow_log($j->ID,'draft','Recovered orphan worker claim during claim contention');
                                }
                                hcdecor_workflow_lifecycle_mutex_release($j->ID,$lifecycle);
                                if($still_orphan && add_post_meta($j->ID,'hc_agent_claim_token',$claim_token,true)){
                                    if(hcdecor_workflow_finalize_claim($j->ID,$claim_token,$now,'Agent claimed recovered job')){
                                        hcdecor_workflow_claim_mutex_release($j->ID,$claim_token);
                                        return hcdecor_workflow_claim_response($j,$claim_token);
                                    }
                                    hcdecor_workflow_clear_owned_claim($j->ID,$claim_token,true);
                                }
                            }
                        }
                    }
                    hcdecor_workflow_claim_mutex_release($j->ID,$claim_token);
                    continue;
                }
                if(!hcdecor_workflow_finalize_claim($j->ID,$claim_token,$now)){
                    hcdecor_workflow_claim_mutex_release($j->ID,$claim_token);
                    continue;
                }
                hcdecor_workflow_claim_mutex_release($j->ID,$claim_token);
                return hcdecor_workflow_claim_response($j,$claim_token);
            }
            return rest_ensure_response(['job'=>null,'message'=>'Queue empty']);
        }
    ]);

    register_rest_route('hcdecor/v1','/operations/jobs/(?P<id>\d+)/heartbeat',[
        'methods'=>'POST','permission_callback'=>'hcdecor_ops_bridge_auth',
        'callback'=>function(WP_REST_Request $r){
            $id=(int)$r['id'];
            if(get_post_type($id)!=='hc_content_job') return new WP_Error('not_found','Job not found',['status'=>404]);
            if(hcdecor_workflow_clip(get_post_meta($id,'hc_agent_status',true),50)!=='processing') return new WP_Error('status','Job is not processing',['status'=>409]);
            $token_raw=$r->get_param('claim_token');$token=is_scalar($token_raw)?sanitize_text_field((string)$token_raw):'';
            if(strlen($token)>128) return new WP_Error('claim','Invalid worker claim token',['status'=>409]);
            $expected=hcdecor_workflow_clip(get_post_meta($id,'hc_agent_claim_token',true),128);
            if($expected==='' || $token==='' || !hash_equals($expected,$token)) return new WP_Error('claim','Invalid worker claim token',['status'=>409]);
            if(!hcdecor_workflow_refresh_owned_claim($id,$token,600)) return new WP_Error('claim','Worker claim changed or expired during heartbeat',['status'=>409]);
            return rest_ensure_response(['ok'=>true,'id'=>$id]);
        }
    ]);

    register_rest_route('hcdecor/v1','/operations/jobs/(?P<id>\d+)/complete',[
        'methods'=>'POST','permission_callback'=>'hcdecor_ops_bridge_auth',
        'callback'=>function(WP_REST_Request $r){
            $id=(int)$r['id'];
            if(get_post_type($id)!=='hc_content_job') return new WP_Error('not_found','Job not found',['status'=>404]);
            if(hcdecor_workflow_clip(get_post_meta($id,'hc_agent_status',true),50)!=='processing') return new WP_Error('status','Job is not processing',['status'=>409]);
            $token_raw=$r->get_param('claim_token');$token=is_scalar($token_raw)?sanitize_text_field((string)$token_raw):'';
            if(strlen($token)>128) return new WP_Error('claim','Invalid worker claim token',['status'=>409]);
            $expected=hcdecor_workflow_clip(get_post_meta($id,'hc_agent_claim_token',true),128);
            if($expected==='' || $token==='' || !hash_equals($expected,$token)) return new WP_Error('claim','Invalid worker claim token',['status'=>409]);
            $lock=(int)get_post_meta($id,'hc_agent_lock_until',true);
            if($lock<=0 || $lock<time()) return new WP_Error('lock','Job lock expired; retry from Review Center',['status'=>409]);
            if(!hcdecor_workflow_owned_claim_active($id,$token)) return new WP_Error('claim','Worker claim changed before saving completion',['status'=>409]);
            $lifecycle=hcdecor_workflow_lifecycle_mutex_acquire($id,$token,30);
            if(!$lifecycle) return new WP_Error('busy','Job completion is already being finalized',['status'=>409]);
            if(!hcdecor_workflow_owned_claim_active($id,$token)){ hcdecor_workflow_lifecycle_mutex_release($id,$lifecycle); return new WP_Error('claim','Worker claim changed before saving completion',['status'=>409]); }
            if(!function_exists('hcdecor_ops_save_fields')){
                hcdecor_workflow_lifecycle_mutex_release($id,$lifecycle);
                return new WP_Error('dependency','Content Operations save handler unavailable',['status'=>503]);
            }
            $p=$r->get_json_params()?:[];
            hcdecor_ops_save_fields($id,$p);
            if(!hcdecor_workflow_owned_claim_active($id,$token)){ hcdecor_workflow_lifecycle_mutex_release($id,$lifecycle); return new WP_Error('claim','Worker claim changed after saving completion',['status'=>409]); }
            if(!hcdecor_workflow_finish_owned_claim($id,$token,'review','Agent completed generation')){ hcdecor_workflow_lifecycle_mutex_release($id,$lifecycle); return new WP_Error('claim','Worker claim changed before completion',['status'=>409]); }
            hcdecor_workflow_lifecycle_mutex_release($id,$lifecycle);
            return rest_ensure_response(['ok'=>true,'id'=>$id,'status'=>'review','outbound'=>false]);
        }
    ]);

    register_rest_route('hcdecor/v1','/operations/jobs/(?P<id>\d+)/fail',[
        'methods'=>'POST','permission_callback'=>'hcdecor_ops_bridge_auth',
        'callback'=>function(WP_REST_Request $r){
            $id=(int)$r['id'];
            if(get_post_type($id)!=='hc_content_job') return new WP_Error('not_found','Job not found',['status'=>404]);
            if(hcdecor_workflow_clip(get_post_meta($id,'hc_agent_status',true),50)!=='processing') return new WP_Error('status','Job is not processing',['status'=>409]);
            $token_raw=$r->get_param('claim_token');$token=is_scalar($token_raw)?sanitize_text_field((string)$token_raw):'';
            if(strlen($token)>128) return new WP_Error('claim','Invalid worker claim token',['status'=>409]);
            $expected=hcdecor_workflow_clip(get_post_meta($id,'hc_agent_claim_token',true),128);
            if($expected==='' || $token==='' || !hash_equals($expected,$token)) return new WP_Error('claim','Invalid worker claim token',['status'=>409]);
            $lock=(int)get_post_meta($id,'hc_agent_lock_until',true);
            if($lock<=0 || $lock<time()) return new WP_Error('lock','Job lock expired; retry from Review Center',['status'=>409]);
            if(!hcdecor_workflow_owned_claim_active($id,$token)) return new WP_Error('claim','Worker claim changed before saving failure',['status'=>409]);
            $lifecycle=hcdecor_workflow_lifecycle_mutex_acquire($id,$token,30);
            if(!$lifecycle) return new WP_Error('busy','Job lifecycle is already being finalized',['status'=>409]);
            if(!hcdecor_workflow_owned_claim_active($id,$token)){ hcdecor_workflow_lifecycle_mutex_release($id,$lifecycle); return new WP_Error('claim','Worker claim changed before failure update',['status'=>409]); }
            $message_raw=$r->get_param('message');$raw_msg=sanitize_text_field(is_scalar($message_raw)?(string)$message_raw:'');
            $msg=function_exists('mb_substr')?mb_substr($raw_msg,0,500):substr($raw_msg,0,500);
            $finished=hcdecor_workflow_finish_owned_claim($id,$token,'failed',$msg?:'Agent failed');
            if($finished) update_post_meta($id,'hc_agent_error',$msg);
            hcdecor_workflow_lifecycle_mutex_release($id,$lifecycle);
            if(!$finished) return new WP_Error('claim','Worker claim changed before failure update',['status'=>409]);
            return rest_ensure_response(['ok'=>true,'id'=>$id,'status'=>'failed','outbound'=>false]);
        }
    ]);
});

add_action('admin_menu',function(){
    add_submenu_page('hcdecor-hub','Review Center','Review Center','edit_posts','hcdecor-review','hcdecor_review_page',2);
},22);

function hcdecor_workflow_recover_stale_jobs($limit=10){
    $now=time();
    $jobs=get_posts([
        'post_type'=>'hc_content_job','post_status'=>'publish','numberposts'=>max(1,min(50,(int)$limit)),
        'meta_query'=>[['key'=>'hc_agent_status','value'=>'processing']]
    ]);
    $recovered=0;
    foreach($jobs as $job){
        $lock=(int)get_post_meta($job->ID,'hc_agent_lock_until',true);
        $claimed=hcdecor_workflow_time(get_post_meta($job->ID,'hc_agent_claimed_at',true));
        $heartbeat=hcdecor_workflow_time(get_post_meta($job->ID,'hc_agent_heartbeat',true));
        $token=hcdecor_workflow_clip(get_post_meta($job->ID,'hc_agent_claim_token',true),128);
        $last_worker_activity=max($claimed,$heartbeat);
        $invalid_claim=($token==='' && $last_worker_activity>0 && $last_worker_activity<($now-120));
        if($invalid_claim || ($lock>0 && $lock<$now) || ($lock<=0 && $claimed>0 && $claimed<($now-900))){
            $current_token=hcdecor_workflow_clip(get_post_meta($job->ID,'hc_agent_claim_token',true),128);
            $current_lock=(int)get_post_meta($job->ID,'hc_agent_lock_until',true);
            if($current_token!==$token || $current_lock!==$lock) continue;
            $note=$invalid_claim?'Worker claim token missing; safe retry available':'Processing lock expired; safe retry available';
            if($token!==''){
                $lifecycle=hcdecor_workflow_lifecycle_mutex_acquire($job->ID,$token,30);
                if(!$lifecycle) continue;
                $finished=hcdecor_workflow_finish_owned_claim($job->ID,$token,'failed',$note);
                hcdecor_workflow_lifecycle_mutex_release($job->ID,$lifecycle);
                if(!$finished) continue;
            }else{
                $lifecycle=hcdecor_workflow_lifecycle_mutex_acquire($job->ID,'recovery-'.$job->ID,30);
                if(!$lifecycle) continue;
                $current_status=hcdecor_workflow_clip(get_post_meta($job->ID,'hc_agent_status',true),50);
                $current_token=hcdecor_workflow_clip(get_post_meta($job->ID,'hc_agent_claim_token',true),128);
                $current_lock=(int)get_post_meta($job->ID,'hc_agent_lock_until',true);
                if($current_status!=='processing' || $current_token!=='' || $current_lock!==$lock){
                    hcdecor_workflow_lifecycle_mutex_release($job->ID,$lifecycle);
                    continue;
                }
                $finished=hcdecor_workflow_set_status($job->ID,'failed',$note);
                if($finished) hcdecor_workflow_clear_worker_claim($job->ID,true,false);
                hcdecor_workflow_lifecycle_mutex_release($job->ID,$lifecycle);
                if(!$finished) continue;
            }
            update_post_meta($job->ID,'hc_agent_recovered_at',current_time('mysql'));
            update_post_meta($job->ID,'hc_agent_recovery_reason',$invalid_claim?'missing_claim_token':'expired_lock');
            $recovered++;
        }
    }
    return $recovered;
}

add_action('hcdecor_ai_worker_tick',function(){
    hcdecor_workflow_recover_stale_jobs(20);
},5);

add_action('admin_post_hcdecor_review_action',function(){
    if(!current_user_can('edit_posts')) wp_die('Forbidden');
    $job_raw=$_POST['job_id']??0;$id=is_scalar($job_raw)?(int)$job_raw:0;
    check_admin_referer('hcdecor_review_'.$id);
    if(get_post_type($id)!=='hc_content_job' || !current_user_can('edit_post',$id)) wp_die('Invalid job');
    $action_raw=$_POST['review_action']??'';$action=sanitize_key(is_scalar($action_raw)?(string)$action_raw:'');
    $note_raw=wp_unslash($_POST['review_note']??'');$note=sanitize_textarea_field(is_scalar($note_raw)?(string)$note_raw:'');
    $note=function_exists('mb_substr')?mb_substr($note,0,5000):substr($note,0,5000);
    if($action==='approve'){
        if(hcdecor_workflow_clip(get_post_meta($id,'hc_agent_status',true),50)!=='review') wp_die('Job is not ready for approval.');
        update_post_meta($id,'hc_reviewed_by',get_current_user_id());
        update_post_meta($id,'hc_reviewed_at',current_time('mysql'));
        if($note!=='') update_post_meta($id,'hc_review_note',$note);
        if(!hcdecor_workflow_set_status($id,'approved','Approved by reviewer')){
            delete_post_meta($id,'hc_reviewed_by');
            delete_post_meta($id,'hc_reviewed_at');
            wp_die('Unable to approve job.');
        }
    }elseif($action==='approve_publish'){
        if(!current_user_can('publish_posts')) wp_die('Forbidden');
        $production_approved=$_POST['production_approved']??'';if(!is_scalar($production_approved) || (string)$production_approved!=='1') wp_die('Explicit production publish approval is required.');
        if(hcdecor_workflow_clip(get_post_meta($id,'hc_agent_status',true),50)!=='review') wp_die('Job is not ready for approval.');
        if(!function_exists('hcdecor_publish_job_to_web')) wp_die('Web publisher unavailable');
        update_post_meta($id,'hc_reviewed_by',get_current_user_id());
        update_post_meta($id,'hc_reviewed_at',current_time('mysql'));
        if($note!=='') update_post_meta($id,'hc_review_note',$note);
        if(!hcdecor_workflow_set_status($id,'approved','Approved by reviewer')){
            delete_post_meta($id,'hc_reviewed_by');
            delete_post_meta($id,'hc_reviewed_at');
            wp_die('Unable to approve job for publishing.');
        }
        update_post_meta($id,'hc_publish_approved_by',get_current_user_id());
        update_post_meta($id,'hc_publish_approval_source','wp_user');
        update_post_meta($id,'hc_publish_approved_at',current_time('mysql'));
        $published=hcdecor_publish_job_to_web($id);
        if(is_wp_error($published)){
            delete_post_meta($id,'hc_publish_approved_by');
            delete_post_meta($id,'hc_publish_approved_at');
            delete_post_meta($id,'hc_publish_approval_source');
            wp_die(function_exists('hcdecor_ai_safe_error')?hcdecor_ai_safe_error($published->get_error_message()):'Web publish failed.');
        }
        wp_safe_redirect(admin_url('admin.php?page=hcdecor-review&job='.$id.'&published=1')); exit;
    }elseif($action==='changes'){
        if(hcdecor_workflow_clip(get_post_meta($id,'hc_agent_status',true),50)!=='review') wp_die('Job is not ready to return for changes.');
        delete_post_meta($id,'hc_reviewed_by');
        delete_post_meta($id,'hc_reviewed_at');
        delete_post_meta($id,'hc_publish_approved_by');
        delete_post_meta($id,'hc_publish_approved_at');
        delete_post_meta($id,'hc_publish_approval_source');
        hcdecor_workflow_clear_worker_claim($id,true,false);
        hcdecor_workflow_set_status($id,'draft','Returned for changes');
        update_post_meta($id,'hc_review_note',$note);
        $ai_ready=function_exists('hcdecor_ai_worker_enabled') && hcdecor_ai_worker_enabled() && function_exists('hcdecor_ai_available') && (hcdecor_ai_available('openai') || hcdecor_ai_available('gemini'));
        if($ai_ready && function_exists('wp_schedule_single_event') && !wp_next_scheduled('hcdecor_ai_process_job',[$id])) wp_schedule_single_event(time()+3,'hcdecor_ai_process_job',[$id]);
    }elseif($action==='retry' && hcdecor_workflow_clip(get_post_meta($id,'hc_agent_status',true),50)==='failed'){
        wp_clear_scheduled_hook('hcdecor_ai_process_job',[$id]);
        delete_post_meta($id,'hc_reviewed_by');
        delete_post_meta($id,'hc_reviewed_at');
        delete_post_meta($id,'hc_publish_approved_by');
        delete_post_meta($id,'hc_publish_approved_at');
        delete_post_meta($id,'hc_publish_approval_source');
        hcdecor_workflow_set_status($id,'draft','Retry requested by reviewer');
        hcdecor_workflow_clear_worker_claim($id,true,false);
        $mutex_key='hcdecor_claim_mutex_'.$id;
        $observed=get_option($mutex_key,[]);
        $mutex_at=is_array($observed)?(int)($observed['at']??0):(int)$observed;
        if($observed && (!$mutex_at || $mutex_at<(time()-120))) hcdecor_workflow_claim_mutex_delete_if_same($mutex_key,$observed);
        $ai_ready=function_exists('hcdecor_ai_worker_enabled') && hcdecor_ai_worker_enabled() && function_exists('hcdecor_ai_available') && (hcdecor_ai_available('openai') || hcdecor_ai_available('gemini'));
        if($ai_ready && function_exists('wp_schedule_single_event') && !wp_next_scheduled('hcdecor_ai_process_job',[$id])) wp_schedule_single_event(time()+3,'hcdecor_ai_process_job',[$id]);
    }
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-review&job='.$id.'&done=1')); exit;
});

function hcdecor_review_page(){
    if(!current_user_can('edit_posts')) return;
    $jobs=get_posts([
        'post_type'=>'hc_content_job','post_status'=>'publish','numberposts'=>50,
        'orderby'=>'modified','order'=>'DESC',
        'meta_query'=>[['key'=>'hc_agent_status','value'=>['review','approved','failed'],'compare'=>'IN']]
    ]);
    $job_raw=$_GET['job']??($jobs[0]->ID??0);$job_id=is_scalar($job_raw)?(int)$job_raw:0;
    $job=$job_id&&get_post_type($job_id)==='hc_content_job'?get_post($job_id):null;
    ?>
    <div class="wrap hcr"><style>
    .hcr{max-width:1450px}.hcr-head{display:flex;justify-content:space-between;align-items:center;margin:16px 0}.hcr-grid{display:grid;grid-template-columns:280px minmax(520px,1fr);gap:14px}.hcr-card{background:#fff;border:1px solid #dcdcde;border-radius:14px;overflow:hidden}.hcr-card h2{font-size:14px;margin:0;padding:14px 16px;border-bottom:1px solid #eee}.hcr-body{padding:14px}.hcr-job{display:block;text-decoration:none;color:#1d2327;border:1px solid #eee;border-radius:10px;padding:10px;margin-bottom:8px}.hcr-job.active{border-color:#c7863d;background:#fff9f2}.hcr-job small{display:block;color:#777}.hcr-preview{display:grid;grid-template-columns:1fr 1fr;gap:12px}.hcr-channel{border:1px solid #e4e4e4;border-radius:12px;padding:14px;background:#fafafa}.hcr-channel h3{margin:0 0 8px}.hcr-channel p{white-space:pre-wrap}.hcr-status{display:inline-block;padding:6px 9px;border-radius:999px;background:#17191c;color:#f2b66f;font-weight:700;font-size:12px}.hcr-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}.hcr textarea{width:100%;min-height:70px}@media(max-width:900px){.hcr-grid{grid-template-columns:1fr}.hcr-preview{grid-template-columns:1fr}}@media(max-width:600px){.hcr{margin-right:10px}.hcr-head{display:block}.hcr-actions{position:sticky;bottom:0;background:#fff;padding:10px 0;z-index:2}.hcr-actions .button{width:100%;min-height:44px;justify-content:center}.hcr textarea{font-size:16px;min-height:90px}.hcr-job{padding:13px}}
    </style>
    <div class="hcr-head"><div><h1>HCDecor Review Center</h1><p>Kiểm tra nội dung Agent trước khi publish.</p></div><span class="hcr-status">SOCIAL OUTBOUND OFF</span></div>
    <div class="hcr-grid"><aside class="hcr-card"><h2>REVIEW QUEUE</h2><div class="hcr-body">
    <?php foreach($jobs as $j): $s=hcdecor_workflow_clip(get_post_meta($j->ID,'hc_agent_status',true),50);?>
      <a class="hcr-job <?php echo $job_id===$j->ID?'active':'';?>" href="<?php echo esc_url(admin_url('admin.php?page=hcdecor-review&job='.$j->ID));?>"><strong><?php echo esc_html($j->post_title);?></strong><small><?php echo esc_html(strtoupper($s));?></small></a>
    <?php endforeach; if(!$jobs):?><p>Chưa có job cần review.</p><?php endif;?>
    </div></aside>
    <section class="hcr-card"><h2>CONTENT REVIEW</h2><div class="hcr-body">
    <?php if($job):
      $status=hcdecor_workflow_clip(get_post_meta($job_id,'hc_agent_status',true),50);
      $fields=[
        'Web'=>[hcdecor_workflow_clip(get_post_meta($job_id,'hc_web_title',true),300),hcdecor_workflow_clip(get_post_meta($job_id,'hc_web_intro',true),2000)."

".hcdecor_workflow_clip(get_post_meta($job_id,'hc_web_body',true),50000)],
        'Facebook'=>['',hcdecor_workflow_clip(get_post_meta($job_id,'hc_facebook_caption',true),10000)],
        'TikTok / Reels'=>['',hcdecor_workflow_clip(get_post_meta($job_id,'hc_tiktok_script',true),20000)],
        'YouTube'=>[hcdecor_workflow_clip(get_post_meta($job_id,'hc_youtube_title',true),300),hcdecor_workflow_clip(get_post_meta($job_id,'hc_youtube_description',true),20000)]
      ];?>
      <p><span class="hcr-status"><?php echo esc_html(strtoupper($status));?></span></p>
      <?php
      $preflight_error='';
      if($status==='approved' && function_exists('hcdecor_publish_preflight')){
          $pf=hcdecor_publish_preflight($job_id);
          if(is_wp_error($pf)) $preflight_error=$pf->get_error_message();
      }
      if($preflight_error!==''):?><div class="notice notice-error inline"><p><strong>Publish blocked:</strong> <?php echo esc_html($preflight_error);?></p></div><?php endif;?>
      <div class="hcr-preview"><?php foreach($fields as $name=>$x):?><div class="hcr-channel"><h3><?php echo esc_html($name);?></h3><?php if($x[0]):?><strong><?php echo esc_html($x[0]);?></strong><?php endif;?><p><?php echo esc_html(trim($x[1]));?></p></div><?php endforeach;?></div>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><?php wp_nonce_field('hcdecor_review_'.$job_id);?><input type="hidden" name="action" value="hcdecor_review_action"><input type="hidden" name="job_id" value="<?php echo $job_id;?>">
        <label><strong>Ghi chú chỉnh sửa</strong></label><textarea name="review_note"></textarea>
        <?php if($status==='review' && current_user_can('publish_posts')):?><label style="display:block;margin:8px 0"><input type="checkbox" name="production_approved" value="1"> Tôi xác nhận Approve + Publish Web sẽ cập nhật nội dung production public.</label><?php endif;?><div class="hcr-actions"><?php if($status==='failed'):?><button class="button button-primary" name="review_action" value="retry">Retry AI</button><?php else:?><button class="button" name="review_action" value="changes">Trả về chỉnh sửa</button><?php endif;?><?php if($status==='review'):?><button class="button" name="review_action" value="approve">Approve</button><?php if(current_user_can('publish_posts')):?><button class="button button-primary" name="review_action" value="approve_publish">Approve + Publish Web</button><?php endif;?><?php endif;?><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=hcdecor-content-operations&job='.$job_id));?>">Mở Content Job</a></div>
      </form>
      <?php if($status==='approved' && $preflight_error===''):?><p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=hcdecor-content-operations&job='.$job_id));?>">Publish Web trong Content Operations</a></p><?php endif;?>
    <?php else:?><p>Chưa có Content Job để review.</p><?php endif;?>
    </div></section></div></div><?php
}
