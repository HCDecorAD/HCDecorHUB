<?php
if (!defined('ABSPATH')) { exit; }

function hcdecor_social_limit_text($value,$limit) {
    $text = sanitize_text_field(is_scalar($value)?(string)$value:'');
    return function_exists('mb_substr') ? mb_substr($text, 0, $limit) : substr($text, 0, $limit);
}
function hcdecor_social_account_normalize($account){
    $account=is_array($account)?$account:[];$channel=sanitize_key(is_scalar($account['channel']??'')?(string)$account['channel']:'');
    $token=is_scalar($account['token']??'')?trim((string)$account['token']):'';if(strlen($token)>8192)$token='';
    return ['id'=>hcdecor_social_limit_text(sanitize_key(is_scalar($account['id']??'')?(string)$account['id']:''),100),'channel'=>in_array($channel,['facebook','tiktok','youtube'],true)?$channel:'','name'=>hcdecor_social_limit_text($account['name']??'',300),'remote_id'=>hcdecor_social_limit_text($account['remote_id']??'',500),'token'=>$token,'group'=>hcdecor_social_limit_text(sanitize_key(is_scalar($account['group']??'')?(string)$account['group']:''),100),'enabled'=>!empty($account['enabled'])];
}
function hcdecor_social_accounts() {
    $value = get_option('hcdecor_social_accounts', []);if(!is_array($value))return [];$out=[];
    foreach(array_slice(array_values($value),-50) as $account){$safe=hcdecor_social_account_normalize($account);if($safe['id']!==''&&$safe['channel']!=='')$out[]=$safe;}return $out;
}
function hcdecor_social_groups() {
    $value = get_option('hcdecor_social_groups', []);if(!is_array($value))return [];
    $out=[];foreach(array_slice($value,-50,null,true) as $key=>$name){$safe_key=hcdecor_social_limit_text(sanitize_key(is_scalar($key)?(string)$key:''),100);if($safe_key==='')continue;$out[$safe_key]=hcdecor_social_limit_text($name,300);}return $out;
}
function hcdecor_social_accounts_safe() {
    return array_map(function($account){
        $account=is_array($account)?$account:[];
        $channel=sanitize_key(is_scalar($account['channel']??'')?(string)$account['channel']:'');
        return [
            'id'=>hcdecor_social_limit_text(sanitize_key(is_scalar($account['id']??'')?(string)$account['id']:''),100),
            'channel'=>in_array($channel,['facebook','tiktok','youtube'],true)?$channel:'',
            'name'=>hcdecor_social_limit_text($account['name']??'',300),
            'remote_id'=>hcdecor_social_limit_text($account['remote_id']??'',500),
            'group'=>hcdecor_social_limit_text(sanitize_key(is_scalar($account['group']??'')?(string)$account['group']:''),100),
            'enabled'=>!empty($account['enabled'])
        ];
    }, hcdecor_social_accounts());
}
function hcdecor_social_groups_safe(){
    $out=[];
    foreach(hcdecor_social_groups() as $key=>$name){$safe_key=hcdecor_social_limit_text(sanitize_key(is_scalar($key)?(string)$key:''),100);if($safe_key!=='')$out[$safe_key]=hcdecor_social_limit_text($name,300);}
    return $out;
}
function hcdecor_social_account($id) {
    foreach (hcdecor_social_accounts() as $account) {
        if (($account['id'] ?? '') === $id) { return $account; }
    }
    return null;
}

add_action('admin_post_hcdecor_social_account_save', function () {
    if (!current_user_can('manage_options')) { wp_die('Forbidden'); }
    check_admin_referer('hcdecor_social_account_save');
    $all = hcdecor_social_accounts();
    $id_raw=$_POST['account_id']??'';$id=sanitize_key(is_scalar($id_raw)?(string)$id_raw:'');
    if (!$id) { $id = 'acc_' . wp_generate_password(10, false, false); }
    $channel_raw=$_POST['channel']??'';$channel=sanitize_key(is_scalar($channel_raw)?(string)$channel_raw:'');
    if (!in_array($channel, ['facebook','tiktok','youtube'], true)) { wp_die('Invalid social channel'); }
    $token_input=wp_unslash($_POST['token']??'');$token_input=is_scalar($token_input)?trim((string)$token_input):'';
    if(strlen($token_input)>8192) wp_die('Social credential value too long.');
    $row = [
        'id' => $id,
        'channel' => $channel,
        'name' => hcdecor_social_limit_text(wp_unslash($_POST['name'] ?? ''), 300),
        'remote_id' => hcdecor_social_limit_text(wp_unslash($_POST['remote_id'] ?? ''), 500),
        'token' => $token_input,
        'group' => sanitize_key(is_scalar($_POST['group']??'')?(string)$_POST['group']:''),
        'enabled' => !empty($_POST['enabled']),
    ];
    $found = false;
    foreach ($all as &$account) {
        if (($account['id'] ?? '') !== $id) { continue; }
        if ($row['token'] === '') { $row['token'] = $account['token'] ?? ''; }
        $account = $row;
        $found = true;
        break;
    }
    unset($account);
    if (!$found) { $all[] = $row; }
    update_option('hcdecor_social_accounts', array_slice(array_values($all), -50), false);
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-social-manager&saved=1'));
    exit;
});

add_action('admin_post_hcdecor_social_group_save', function () {
    if (!current_user_can('manage_options')) { wp_die('Forbidden'); }
    check_admin_referer('hcdecor_social_group_save');
    $groups = hcdecor_social_groups();
    $key_raw=$_POST['group_key']??'';$key=sanitize_key(is_scalar($key_raw)?(string)$key_raw:'');
    if ($key) { $groups[$key] = hcdecor_social_limit_text(wp_unslash($_POST['group_name'] ?? $key), 300); }
    update_option('hcdecor_social_groups', array_slice($groups, -50, null, true), false);
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-social-manager'));
    exit;
});

add_action('admin_post_hcdecor_social_bulk_publish', function () {
    if (!current_user_can('manage_options')) { wp_die('Forbidden'); }
    check_admin_referer('hcdecor_social_bulk_publish');
    $approval_raw=$_POST['production_approved']??'';if (!is_scalar($approval_raw) || (string)$approval_raw !== '1') {
        wp_die('Explicit production approval is required before social publishing can be queued.');
    }
    $accounts_raw=$_POST['accounts']??[];$ids=array_values(array_filter(array_map(function($id){return is_scalar($id)?sanitize_key((string)$id):'';},is_array($accounts_raw)?$accounts_raw:[])));
    $group_raw=$_POST['account_group']??'';$group=sanitize_key(is_scalar($group_raw)?(string)$group_raw:'');
    if ($group) {
        foreach (hcdecor_social_accounts() as $account) {
            if (($account['group'] ?? '') === $group) { $ids[] = $account['id']; }
        }
        $ids = array_values(array_unique($ids));
    }
    $ids=array_slice(array_values(array_unique($ids)),0,50);
    $media_input=wp_unslash($_POST['media_ids'] ?? '');$media_input=is_scalar($media_input)?(string)$media_input:'';
    if(strlen($media_input)>5000) wp_die('Media selection is too large.');
    $media_raw = sanitize_text_field($media_input);
    $media = array_slice(array_values(array_filter(array_unique(array_map('intval', preg_split('/[\s,]+/', $media_raw))), function($id){ return get_post_type($id)==='attachment'; })), 0, 60);
    $caption_input=wp_unslash($_POST['caption'] ?? '');$caption_input=is_scalar($caption_input)?(string)$caption_input:'';
    if(strlen($caption_input)>20000) wp_die('Social caption is too large.');
    $caption = sanitize_textarea_field($caption_input);
    $caption = function_exists('mb_substr') ? mb_substr($caption, 0, 10000) : substr($caption, 0, 10000);
    $when_raw=wp_unslash($_POST['run_at'] ?? '');$when_raw=is_scalar($when_raw)?(string)$when_raw:'';
    if(strlen($when_raw)>64) wp_die('Invalid social publish schedule.');
    $when = sanitize_text_field($when_raw);
    $run = $when ? strtotime($when) : time();
    if ($when !== '' && $run === false) { wp_die('Invalid social publish schedule.'); }
    $run = max(time(), (int)$run);
    if($run>time()+10*MINUTE_IN_SECONDS) wp_die('Social publish schedule must run within 10 minutes of fresh approval.');
    $batch = 'social_' . wp_generate_password(10, false, false);
    $created = 0;
    foreach ($ids as $id) {
        $account = hcdecor_social_account($id);
        if (!$account || empty($account['enabled']) || !in_array(($account['channel'] ?? ''), ['facebook','tiktok','youtube'], true)) { continue; }
        $payload = [
            'batch_id' => $batch,
            'account_id' => $id,
            'channel' => $account['channel'],
            'remote_id' => $account['remote_id'],
            'caption' => $caption,
            'media_ids' => $media,
            'status' => 'ready',
            'production_approved' => true,
            'production_approved_by' => get_current_user_id(),
            'production_approved_at' => current_time('mysql'),
            'production_approval_source' => 'wp_user',
        ];
        $result = function_exists('hcdecor_auto_enqueue')
            ? hcdecor_auto_enqueue('social_publish', $payload, $run, 'bulk:' . $batch . ':' . $id)
            : new WP_Error('automation', 'Automation unavailable');
        if (!is_wp_error($result)) {
            $created++;
            update_post_meta($result, 'hc_auto_account_id', $id);
            update_post_meta($result, 'hc_auto_batch_id', $batch);
        }
    }
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-social-manager&queued=' . $created));
    exit;
});

add_action('admin_menu', function () {
    add_submenu_page('hcdecor-hub', 'Social Manager', 'Social Manager', 'manage_options', 'hcdecor-social-manager', 'hcdecor_social_manager_page', 5);
}, 28);

function hcdecor_social_manager_page() {
    if (!current_user_can('manage_options')) { return; }
    $accounts = hcdecor_social_accounts();
    $groups = hcdecor_social_groups();
    ?>
    <div class="wrap hcsm">
      <style>.hcsm{max-width:1450px}.hcsm-grid{display:grid;grid-template-columns:1.2fr .8fr;gap:14px}.hcsm-card{background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:16px}.hcsm-accounts{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.hcsm-account{border:1px solid #e4e4e7;border-radius:12px;padding:12px}.hcsm-account small{display:block;color:#646970}.hcsm-form input,.hcsm-form select,.hcsm-form textarea{width:100%;margin:5px 0 10px}.hcsm-check{display:flex;gap:7px;align-items:center;margin:7px 0}.hcsm-check input{width:auto;margin:0}@media(max-width:900px){.hcsm-grid,.hcsm-accounts{grid-template-columns:1fr}}</style>
      <h1>Social Manager · Multi Account</h1>
      <p>Chọn nhiều tài khoản, nhiều media, đăng ngay hoặc lên lịch theo batch.</p>
      <?php if (isset($_GET['queued'])) : ?><div class="notice notice-success inline"><p>Đã tạo <?php echo (int) $_GET['queued']; ?> job trong hàng đợi.</p></div><?php endif; ?>
      <div class="hcsm-grid">
        <section class="hcsm-card"><h2>Tài khoản</h2><div class="hcsm-accounts">
          <?php foreach ($accounts as $account) : ?><div class="hcsm-account"><strong><?php echo esc_html($account['name']); ?></strong><small><?php echo esc_html(strtoupper($account['channel']) . ' · ' . ($account['group'] ?? 'Không nhóm')); ?></small><small><?php echo !empty($account['enabled']) ? '● Active' : '○ Disabled'; ?></small></div><?php endforeach; ?>
          <?php if (!$accounts) : ?><p>Chưa có tài khoản.</p><?php endif; ?>
        </div>
        <h3>Thêm / cập nhật tài khoản</h3>
        <form class="hcsm-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="hcdecor_social_account_save"><?php wp_nonce_field('hcdecor_social_account_save'); ?><input name="name" placeholder="Tên tài khoản / Page"><select name="channel"><option value="facebook">Facebook</option><option value="tiktok">TikTok</option><option value="youtube">YouTube</option></select><input name="remote_id" placeholder="Page ID / Channel ID / Account ID"><input type="password" name="token" placeholder="Access token"><select name="group"><option value="">Không nhóm</option><?php foreach ($groups as $key => $name) : ?><option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($name); ?></option><?php endforeach; ?></select><label><input type="checkbox" name="enabled" value="1" checked> Active</label><p><button class="button button-primary">Lưu tài khoản</button></p></form>
        </section>
        <section class="hcsm-card"><h2>Nhóm tài khoản</h2>
          <form class="hcsm-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="hcdecor_social_group_save"><?php wp_nonce_field('hcdecor_social_group_save'); ?><input name="group_key" placeholder="vd: hcdecor"><input name="group_name" placeholder="HCDecor"><button class="button">Thêm nhóm</button></form>
          <hr><h2>Bulk Publisher</h2>
          <form class="hcsm-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="hcdecor_social_bulk_publish"><?php wp_nonce_field('hcdecor_social_bulk_publish'); ?><label>Chọn nhóm</label><select name="account_group"><option value="">—</option><?php foreach ($groups as $key => $name) : ?><option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($name); ?></option><?php endforeach; ?></select><label>Hoặc chọn nhiều tài khoản</label><?php foreach ($accounts as $account) : ?><label class="hcsm-check"><input type="checkbox" name="accounts[]" value="<?php echo esc_attr($account['id']); ?>"> <?php echo esc_html($account['name'] . ' · ' . strtoupper($account['channel'])); ?></label><?php endforeach; ?><label>Media IDs — chọn nhiều</label><input name="media_ids" placeholder="125, 126, 130"><label>Nội dung / Caption</label><textarea name="caption" rows="5"></textarea><label>Lịch đăng</label><input type="datetime-local" name="run_at"><label class="hcsm-check"><input type="checkbox" name="production_approved" value="1" required> Tôi xác nhận phê duyệt gửi nội dung này ra các kênh production đã chọn.</label><button class="button button-primary button-hero">Phê duyệt & đưa vào hàng đợi</button></form>
        </section>
      </div>
    </div>
    <?php
}

add_action('rest_api_init', function () {
    register_rest_route('hcdecor/v1', '/social/accounts', [
        'methods' => 'GET',
        'permission_callback' => 'hcdecor_ops_bridge_auth',
        'callback' => function () {
            return rest_ensure_response(['accounts' => hcdecor_social_accounts_safe(), 'groups' => hcdecor_social_groups_safe()]);
        },
    ]);
});
