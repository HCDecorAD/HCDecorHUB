<?php
if (!defined('ABSPATH')) exit;

/**
 * HCDecor Automation Recipes + Connector Layer
 * Trigger -> Conditions -> Actions
 */

function hcdecor_connector_registry(){
    return apply_filters('hcdecor_connector_registry',[
        'wordpress'=>[
            'label'=>'WordPress',
            'status'=>'local_available',
            'actions'=>['publish_project','update_project','create_media_meta']
        ],
        'webhook'=>[
            'label'=>'Webhook',
            'status'=>hcdecor_auto_settings()['webhook_enabled']?'configured':'not_configured',
            'actions'=>['send_webhook']
        ],
        'facebook'=>[
            'label'=>'Facebook',
            'status'=>function_exists('hcdecor_social_connection_state')&&hcdecor_social_connection_state('facebook')['configured']?'configured':'not_configured',
            'actions'=>['publish_post','publish_reel']
        ],
        'tiktok'=>[
            'label'=>'TikTok',
            'status'=>function_exists('hcdecor_social_connection_state')&&hcdecor_social_connection_state('tiktok')['configured']?'configured':'not_configured',
            'actions'=>['publish_video']
        ],
        'youtube'=>[
            'label'=>'YouTube',
            'status'=>function_exists('hcdecor_social_connection_state')&&hcdecor_social_connection_state('youtube')['configured']?'configured':'not_configured',
            'actions'=>['publish_video','update_description']
        ],
        'drive'=>[
            'label'=>'Google Drive Vault',
            'status'=>function_exists('hcdecor_drive_configured')&&hcdecor_drive_configured()?'configured':'not_configured',
            'actions'=>['save_job','load_job','archive_media','save_prompt','export_package']
        ]
    ]);
}

function hcdecor_recipe_defaults(){
    return [
        [
            'id'=>'project_to_ai',
            'name'=>'Project + Media → HUB Agent',
            'enabled'=>false,
            'trigger'=>'project_media_ready',
            'conditions'=>[['field'=>'media_count','op'=>'>','value'=>0]],
            'actions'=>[['type'=>'create_content_job'],['type'=>'run_ai']]
        ],
        [
            'id'=>'approved_to_web',
            'name'=>'Approved → Publish Web',
            'enabled'=>false,
            'trigger'=>'content_approved',
            'conditions'=>[],
            'actions'=>[['type'=>'publish_web']]
        ],
        [
            'id'=>'review_to_drive',
            'name'=>'AI Review → Save Drive Vault',
            'enabled'=>false,
            'trigger'=>'content_review',
            'conditions'=>[],
            'actions'=>[['type'=>'save_drive']]
        ],
        [
            'id'=>'web_to_social_queue',
            'name'=>'Web Published → Social Queue',
            'enabled'=>false,
            'trigger'=>'web_published',
            'conditions'=>[],
            'actions'=>[['type'=>'enqueue_social']]
        ],
        [
            'id'=>'evergreen',
            'name'=>'Evergreen Project → Re-share',
            'enabled'=>false,
            'trigger'=>'daily',
            'conditions'=>[['field'=>'age_days','op'=>'>=','value'=>30]],
            'actions'=>[['type'=>'enqueue_social']]
        ]
    ];
}

function hcdecor_recipes(){
    $defaults=hcdecor_recipe_defaults();$saved=get_option('hcdecor_automation_recipes',[]);$enabled=[];
    if(is_array($saved)){foreach(array_slice($saved,0,100) as $recipe){if(!is_array($recipe))continue;$id=sanitize_key(is_scalar($recipe['id']??'')?(string)$recipe['id']:'');if($id!=='')$enabled[$id]=!empty($recipe['enabled']);}}
    foreach($defaults as &$recipe){$id=sanitize_key(is_scalar($recipe['id']??'')?(string)$recipe['id']:'');if(array_key_exists($id,$enabled))$recipe['enabled']=$enabled[$id];}unset($recipe);
    return $defaults;
}

function hcdecor_recipe_condition_match($condition,$context){
    $field=sanitize_key(is_scalar($condition['field']??'')?(string)$condition['field']:'');
    $op=is_scalar($condition['op']??'')?(string)$condition['op']:'==';
    $want=$condition['value']??null;
    $got=$context[$field]??null;
    switch($op){
        case '>': return (float)$got>(float)$want;
        case '>=': return (float)$got>=(float)$want;
        case '<': return (float)$got<(float)$want;
        case '<=': return (float)$got<=(float)$want;
        case '!=': return $got!=$want;
        case 'in': return in_array($got,(array)$want,true);
        default: return $got==$want;
    }
}

function hcdecor_recipe_matches($recipe,$trigger,$context){
    if(empty($recipe['enabled']) || ($recipe['trigger']??'')!==$trigger) return false;
    foreach((array)($recipe['conditions']??[]) as $condition){
        if(!hcdecor_recipe_condition_match($condition,$context)) return false;
    }
    return true;
}

function hcdecor_recipe_approval_fresh($context){
    if(empty($context['production_approved']) || empty($context['production_approved_by']) || empty($context['production_approved_at'])) return false;
    $by=is_scalar($context['production_approved_by'])?(string)$context['production_approved_by']:'';
    $source=sanitize_key(is_scalar($context['production_approval_source']??'')?(string)$context['production_approval_source']:'');
    $at_raw=is_scalar($context['production_approved_at'])?(string)$context['production_approved_at']:'';
    if($by==='' || strlen($by)>200 || strlen($source)>50 || strlen($at_raw)>64 || !in_array($source,['wp_user','service_bridge'],true)) return false;
    $at=strtotime($at_raw)?:0;
    return $at>0 && $at>=time()-15*MINUTE_IN_SECONDS && $at<=time()+5*MINUTE_IN_SECONDS;
}

function hcdecor_recipe_execute_action($action,$context){
    $type=sanitize_key(is_scalar($action['type']??'')?(string)$action['type']:'');
    if($type==='create_content_job'){
        if(!function_exists('hcdecor_agent_create_job')) return new WP_Error('agent','Agent intake unavailable');
        return hcdecor_agent_create_job(
            (int)($context['project_id']??0),
            (array)($context['media_ids']??[]),
            is_scalar($context['brief']??'')?(string)$context['brief']:''
        );
    }
    if($type==='run_ai'){
        $job=(int)($context['job_id']??0);
        if(!function_exists('hcdecor_ai_worker_enabled') || !hcdecor_ai_worker_enabled()) return new WP_Error('ai_disabled','AI worker master switch is disabled.');
        if(!$job || !function_exists('hcdecor_ai_generate_job')) return new WP_Error('ai','AI unavailable');
        return hcdecor_ai_generate_job($job);
    }
    if($type==='publish_web'){
        $job=(int)($context['job_id']??0);
        if(!hcdecor_recipe_approval_fresh($context)) return new WP_Error('approval','Fresh explicit production approval is required for recipe web publishing.');
        if(!$job || !function_exists('hcdecor_publish_job_to_web')) return new WP_Error('publish','Web publisher unavailable');
        return hcdecor_publish_job_to_web($job);
    }
    if($type==='enqueue_social'){
        $project=(int)($context['project_id']??0);
        $job=(int)($context['job_id']??0);
        if(!function_exists('hcdecor_auto_prepare_social') || !function_exists('hcdecor_auto_enqueue')) return new WP_Error('automation','Automation queue unavailable');
        if(!hcdecor_recipe_approval_fresh($context)) return new WP_Error('approval','Fresh explicit production approval is required for recipe social publishing.');
        $prepared=hcdecor_auto_prepare_social($project,$job);
        if(is_wp_error($prepared)) return $prepared;
        $prepared['production_approved']=true;
        $prepared['production_approved_by']=(int)$context['production_approved_by'];
        $prepared['production_approved_at']=is_scalar($context['production_approved_at']??'')?(string)$context['production_approved_at']:'';
        $prepared['production_approval_source']=sanitize_key(is_scalar($context['production_approval_source']??'')?(string)$context['production_approval_source']:'');
        return hcdecor_auto_enqueue('social_publish',$prepared,time(),'recipe:social:'.$project.':'.$job);
    }
    if($type==='save_drive'){
        $job=(int)($context['job_id']??0);
        if(!function_exists('hcdecor_drive_workflow_auto_sync_enabled') || !hcdecor_drive_workflow_auto_sync_enabled()) return new WP_Error('drive_disabled','Automatic Drive workflow sync is disabled.');
        if(!$job || !function_exists('hcdecor_drive_save_job')) return new WP_Error('drive','Drive Vault unavailable');
        return hcdecor_drive_save_job($job,true);
    }
    if($type==='send_webhook'){
        if(!function_exists('hcdecor_auto_enqueue')) return new WP_Error('automation','Automation queue unavailable');
        if(!hcdecor_recipe_approval_fresh($context)) return new WP_Error('approval','Fresh explicit production approval is required for recipe webhook delivery.');
        $outbound_context=$context;
        unset($outbound_context['production_approved'],$outbound_context['production_approved_by'],$outbound_context['production_approved_at'],$outbound_context['production_approval_source']);
        return hcdecor_auto_enqueue('webhook',[
            'event'=>sanitize_key(is_scalar($action['event']??'')?(string)$action['event']:'hcdecor.recipe'),
            'data'=>$outbound_context,
            'production_approved'=>true,
            'production_approved_by'=>(int)$context['production_approved_by'],
            'production_approved_at'=>is_scalar($context['production_approved_at']??'')?(string)$context['production_approved_at']:'',
            'production_approval_source'=>sanitize_key(is_scalar($context['production_approval_source']??'')?(string)$context['production_approval_source']:'')
        ],time());
    }
    return new WP_Error('action','Unknown recipe action: '.$type);
}

function hcdecor_recipe_fire($trigger,$context=[]){
    $settings=function_exists('hcdecor_auto_settings')?hcdecor_auto_settings():[];
    if(empty($settings['enabled'])) return [];
    $runs=[];
    foreach(hcdecor_recipes() as $recipe){
        if(!hcdecor_recipe_matches($recipe,$trigger,$context)) continue;
        $ctx=$context; $ok=true; $results=[];
        foreach((array)($recipe['actions']??[]) as $action){
            $res=hcdecor_recipe_execute_action($action,$ctx);
            $results[]=$res;
            if(is_wp_error($res)){ $ok=false; break; }
            if(($action['type']??'')==='create_content_job' && is_numeric($res)) $ctx['job_id']=(int)$res;
        }
        $runs[]=['recipe'=>$recipe['id']??'','ok'=>$ok,'results'=>$results];
    }
    return $runs;
}

add_action('hcdecor_recipe_fire',function($trigger,$context=[]){
    hcdecor_recipe_fire($trigger,(array)$context);
},10,2);

add_action('hcdecor_after_web_publish',function($job_id,$project_id){
    do_action('hcdecor_recipe_fire','web_published',[
        'job_id'=>(int)$job_id,
        'project_id'=>(int)$project_id
    ]);
},20,2);

add_action('admin_post_hcdecor_recipe_toggle',function(){
    if(!current_user_can('manage_options')) wp_die('Forbidden');
    $id_raw=$_POST['recipe_id']??'';$id=sanitize_key(is_scalar($id_raw)?(string)$id_raw:'');
    check_admin_referer('hcdecor_recipe_toggle_'.$id);
    $recipes=hcdecor_recipes();
    foreach($recipes as &$recipe){
        if(($recipe['id']??'')===$id) $recipe['enabled']=empty($recipe['enabled']);
    }
    unset($recipe);
    update_option('hcdecor_automation_recipes',$recipes,false);
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-automation&recipe=1')); exit;
});

add_action('admin_footer',function(){
    if(($_GET['page']??'')!=='hcdecor-automation') return;
    $recipes=hcdecor_recipes();
    $connectors=hcdecor_connector_registry(); ?>
    <style>
      .hc-auto-architecture{max-width:1300px;margin:18px 0;display:grid;grid-template-columns:1.15fr .85fr;gap:14px}
      .hc-auto-box{background:#fff;border:1px solid #ddd;border-radius:12px;padding:16px}
      .hc-recipe{border:1px solid #eee;border-radius:10px;padding:12px;margin:8px 0}
      .hc-recipe-flow{font-size:12px;color:#646970;margin-top:4px}
      .hc-connector-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}
      .hc-connector{border:1px solid #eee;border-radius:10px;padding:10px}
      .hc-connector em{font-style:normal;font-size:11px;padding:3px 7px;border-radius:999px;background:#f0f0f1}
      .hc-connector em.configured{background:#dff3e4;color:#176c2f}
      @media(max-width:900px){.hc-auto-architecture{grid-template-columns:1fr}}
    </style>
    <div class="hc-auto-architecture">
      <section class="hc-auto-box"><h2>Recipe Engine</h2>
      <?php foreach($recipes as $r):?>
        <div class="hc-recipe">
          <strong><?php echo esc_html($r['name']);?></strong>
          <div class="hc-recipe-flow"><?php echo esc_html($r['trigger']);?> → <?php echo esc_html(implode(' → ',array_map(function($a){return $a['type']??'';},(array)$r['actions'])));?></div>
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" style="margin-top:8px">
            <input type="hidden" name="action" value="hcdecor_recipe_toggle"><input type="hidden" name="recipe_id" value="<?php echo esc_attr($r['id']);?>">
            <?php wp_nonce_field('hcdecor_recipe_toggle_'.$r['id']);?>
            <button class="button"><?php echo !empty($r['enabled'])?'Disable':'Enable';?></button>
          </form>
        </div>
      <?php endforeach;?>
      </section>
      <section class="hc-auto-box"><h2>Connector Layer</h2><div class="hc-connector-grid">
      <?php foreach($connectors as $id=>$x):?>
        <div class="hc-connector"><strong><?php echo esc_html($x['label']);?></strong><br><em class="<?php echo in_array($x['status'],['local_available','configured'],true)?'configured':'';?>"><?php echo esc_html(strtoupper($x['status']));?></em><div style="margin-top:6px;color:#646970;font-size:12px"><?php echo esc_html(implode(', ',$x['actions']));?></div></div>
      <?php endforeach;?>
      </div></section>
    </div><?php
},50);


add_action('hcdecor_workflow_status_changed',function($job_id,$old,$status){
    if($status==='review'){
        do_action('hcdecor_recipe_fire','content_review',[
            'job_id'=>(int)$job_id,
            'project_id'=>(int)get_post_meta($job_id,'hc_project_id',true),
            'status'=>$status
        ]);
    }
},35,3);
