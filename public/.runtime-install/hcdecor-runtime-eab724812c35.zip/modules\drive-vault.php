<?php
if (!defined('ABSPATH')) exit;

/**
 * HCDecor Drive Vault
 * Google Drive = long-term data vault.
 * WordPress = workflow/index/queue.
 */

function hcdecor_drive_default_folders(){
    return [
        'root'=>'1NqJuLhum63XVea8wPjZtTETl29bm3U7r',
        'command'=>'1Y9Wx8MoHnMxWSyO-mkOa5aidfnp7F8xg',
        'projects'=>'1bKNzYBoDQ-FKb0KegVk1NUinmvV6B5xy',
        'content'=>'1zZkNEh8pOFGaxQVx2QzX7ZO3BJa1OqwE',
        'media'=>'1OIz9cC8X2ztLQk7Qmr9lquQPEDj24T6G',
        'knowledge'=>'1yT-EP7cL1BmBYoojcy2SLU30Yl45Ih6p',
        'templates'=>'1s17AIpqVLv0kUJHhoby3GXRqwL_KzPHY',
        'reports'=>'19MzucieRW3LT9Dq9V_XVNA-VasxNR_iD',
        'automation'=>'1Z55POM2C69WHb8O1fb04YcQ2a7Q9cI1V',
        'archive'=>'1GFNq7Hi0-hRJc11QtFuX7_9LRGfhpq9Z',
        'prompts'=>'1yi00jU--BcjYR1h1cTzSR73F7Xk5yJa-',
        'ai_presets'=>'1eAKZ3Wuy6R2ppNvCT1GVI5f0v8iUuDHc',
        'brand'=>'1w1tygDovmgVN19qmJV51Lo1FokwAHLWE',
        'manifests'=>'1MOgplCZJ9t2BYvoMWqJNzQojLwzdzdv_',
        'content_draft'=>'1z5PXaXro3Q-A0auzPXPkfYMq3ynJ4qSX',
        'content_review'=>'1p-gOd6bOrIgBHMN66SNBMBSf7hVj_Efg',
        'content_approved'=>'14NNMdL8sm5AyGbqIS9Ws17zYcZwQhL6B',
        'content_published'=>'17e1beNodrLcOCfmSKR7TWWkIfoy29yNz',
        'media_input'=>'13xvHhVARk-VqwLwro62bQWTV1rBqc8e4',
        'media_ai'=>'1s1ND4y-ziO3FiQ5rUPbh0Apx0N70LGNw',
        'media_approved'=>'19PLqjuwPbbK_6xIhyunloISYzPLhwh6g',
        'jobs'=>'19GoViim4G1fOHvN2_DQ4uxdBfxT4ndRg',
        'logs'=>'1fuAtzdIH3hzUtArr3dl4r94WBeLRNNih',
        'exports'=>'1ZASnBdvo2snkREvSzMuCSgS8hZX5dnWj',
        'backups'=>'1-tNi0yUg9mNQuabzIRRYyigFM899EfHp'
    ];
}

function hcdecor_drive_folders(){
    $defaults=hcdecor_drive_default_folders();
    $saved=get_option('hcdecor_drive_folders',[]);$saved=is_array($saved)?$saved:[];$out=[];
    foreach($defaults as $key=>$default){
        $value=isset($saved[$key])&&is_scalar($saved[$key])?(string)$saved[$key]:(string)$default;
        $value=preg_replace('/[^A-Za-z0-9_-]/','',$value);
        $out[$key]=$value!==''?substr($value,0,200):(string)$default;
    }
    return $out;
}

function hcdecor_drive_approval_fresh(WP_REST_Request $r){
    if(!rest_sanitize_boolean($r->get_param('production_approved'))) return false;
    $by_raw=$r->get_param('production_approved_by');$source_raw=$r->get_param('production_approval_source');$at_raw=$r->get_param('production_approved_at');
    $by=is_scalar($by_raw)?sanitize_text_field((string)$by_raw):'';
    $source=is_scalar($source_raw)?sanitize_key((string)$source_raw):'';
    $at_raw=is_scalar($at_raw)?(string)$at_raw:'';
    if($by==='' || strlen($by)>200 || strlen($source)>50 || strlen($at_raw)>64 || !in_array($source,['wp_user','service_bridge'],true)) return false;
    $at=strtotime($at_raw)?:0;
    return $at>=time()-15*MINUTE_IN_SECONDS && $at<=time()+5*MINUTE_IN_SECONDS;
}

function hcdecor_drive_secret($name){
    $const=[
        'client_id'=>'HCDECOR_GOOGLE_CLIENT_ID',
        'client_secret'=>'HCDECOR_GOOGLE_CLIENT_SECRET',
        'refresh_token'=>'HCDECOR_GOOGLE_REFRESH_TOKEN'
    ];
    $limits=['client_id'=>1000,'client_secret'=>4000,'refresh_token'=>8000];
    if(!isset($limits[$name])) return '';
    $value=isset($const[$name]) && defined($const[$name])?constant($const[$name]):get_option('hcdecor_drive_'.$name,'');
    if(!is_scalar($value)) return '';$value=trim((string)$value);
    return strlen($value)<=$limits[$name]?$value:'';
}

function hcdecor_drive_configured(){
    return hcdecor_drive_secret('client_id')!=='' && hcdecor_drive_secret('client_secret')!=='' && hcdecor_drive_secret('refresh_token')!=='';
}
function hcdecor_drive_safe_error($message){
    $text=sanitize_text_field(is_scalar($message)?(string)$message:'');
    $text=preg_replace('/\b(?:ya29\.[A-Za-z0-9._-]{12,}|Bearer\s+[A-Za-z0-9._~+\/-]{12,}|1\/\/[A-Za-z0-9_-]{12,})\b/i','[REDACTED]',$text);
    return function_exists('mb_substr')?mb_substr($text,0,500):substr($text,0,500);
}

function hcdecor_drive_clip($value,$limit){
    $value=is_scalar($value)?(string)$value:'';
    return function_exists('mb_substr')?mb_substr($value,0,$limit):substr($value,0,$limit);
}
function hcdecor_drive_job_log($value){
    $out=[];
    foreach(array_slice((array)$value,-100) as $entry){
        if(!is_array($entry)) continue;
        $out[]=['time'=>hcdecor_drive_clip($entry['time']??'',64),'event'=>sanitize_key((string)($entry['event']??'')),'note'=>hcdecor_drive_clip($entry['note']??'',500),'user'=>(int)($entry['user']??0)];
    }
    return $out;
}

function hcdecor_drive_oauth_redirect_uri(){
    return admin_url('admin-post.php?action=hcdecor_drive_oauth_callback');
}

function hcdecor_drive_oauth_connect_url(){
    $client=hcdecor_drive_secret('client_id');
    if($client==='') return '';
    $state=wp_create_nonce('hcdecor_drive_oauth_state');
    return add_query_arg([
        'client_id'=>$client,
        'redirect_uri'=>hcdecor_drive_oauth_redirect_uri(),
        'response_type'=>'code',
        'scope'=>'https://www.googleapis.com/auth/drive',
        'access_type'=>'offline',
        'prompt'=>'consent',
        'include_granted_scopes'=>'true',
        'state'=>$state
    ],'https://accounts.google.com/o/oauth2/v2/auth');
}

add_action('admin_post_hcdecor_drive_oauth_start',function(){
    if(!current_user_can('manage_options')) wp_die('Forbidden');
    check_admin_referer('hcdecor_drive_oauth_start');
    if(hcdecor_drive_secret('client_id')==='' || hcdecor_drive_secret('client_secret')===''){
        wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&oauth_missing=1')); exit;
    }
    wp_redirect(hcdecor_drive_oauth_connect_url()); exit;
});

add_action('admin_post_hcdecor_drive_oauth_callback',function(){
    if(!current_user_can('manage_options')) wp_die('Forbidden');
    $state_raw=wp_unslash($_GET['state']??'');$state=sanitize_text_field(is_scalar($state_raw)?(string)$state_raw:'');
    if(strlen($state)>256 || !$state || !wp_verify_nonce($state,'hcdecor_drive_oauth_state')) wp_die('Invalid OAuth state.');
    if(!empty($_GET['error'])){
        $oauth_raw=wp_unslash($_GET['error']);$oauth_error=sanitize_text_field(is_scalar($oauth_raw)?(string)$oauth_raw:'');
        $oauth_error=function_exists('mb_substr')?mb_substr($oauth_error,0,500):substr($oauth_error,0,500);
        wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&oauth_error='.rawurlencode($oauth_error))); exit;
    }
    $code_raw=wp_unslash($_GET['code']??'');$code=sanitize_text_field(is_scalar($code_raw)?(string)$code_raw:'');
    if(strlen($code)>8192) wp_die('Invalid OAuth code.');
    if($code==='') wp_die('Missing OAuth code.');
    $r=wp_safe_remote_post('https://oauth2.googleapis.com/token',[
        'timeout'=>30,
        'limit_response_size'=>1024*1024,
        'body'=>[
            'code'=>$code,
            'client_id'=>hcdecor_drive_secret('client_id'),
            'client_secret'=>hcdecor_drive_secret('client_secret'),
            'redirect_uri'=>hcdecor_drive_oauth_redirect_uri(),
            'grant_type'=>'authorization_code'
        ]
    ]);
    if(is_wp_error($r)){
        update_option('hcdecor_drive_test_status','error',false);
        update_option('hcdecor_drive_test_message',hcdecor_drive_safe_error($r->get_error_message()),false);
        wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&oauth_failed=1')); exit;
    }
    $status=(int)wp_remote_retrieve_response_code($r);
    $data=json_decode(wp_remote_retrieve_body($r),true);$data=is_array($data)?$data:[];
    $access=is_scalar($data['access_token']??'')?sanitize_text_field((string)$data['access_token']):'';
    $refresh=is_scalar($data['refresh_token']??'')?sanitize_text_field((string)$data['refresh_token']):'';
    if($status<200 || $status>=300 || $access==='' || strlen($access)>16000 || strlen($refresh)>8000){
        update_option('hcdecor_drive_test_status','error',false);
        update_option('hcdecor_drive_test_message',hcdecor_drive_safe_error((string)($data['error_description']??$data['error']??('OAuth HTTP '.$status))),false);
        wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&oauth_failed=1')); exit;
    }
    if($refresh!=='') update_option('hcdecor_drive_refresh_token',$refresh,false);
    set_transient('hcdecor_drive_access_token',$access,max(60,min(DAY_IN_SECONDS,(int)($data['expires_in']??3600)-120)));
    $test=hcdecor_drive_test();
    if(is_wp_error($test)){
        update_option('hcdecor_drive_test_status','error',false);
        update_option('hcdecor_drive_test_message',hcdecor_drive_safe_error($test->get_error_message()),false);
    }else{
        update_option('hcdecor_drive_test_status','ok',false);
        update_option('hcdecor_drive_test_message',sanitize_text_field((string)($test['user']['emailAddress']??'Connected')),false);
        update_option('hcdecor_drive_connected_email',sanitize_email((string)($test['user']['emailAddress']??'')),false);
        update_option('hcdecor_drive_connected_at',current_time('mysql'),false);
    }
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&oauth_connected=1')); exit;
});

add_action('admin_post_hcdecor_drive_disconnect',function(){
    if(!current_user_can('manage_options')) wp_die('Forbidden');
    check_admin_referer('hcdecor_drive_disconnect');
    delete_option('hcdecor_drive_refresh_token');
    delete_option('hcdecor_drive_connected_email');
    delete_option('hcdecor_drive_connected_at');
    delete_option('hcdecor_drive_test_status');
    delete_option('hcdecor_drive_test_message');
    delete_option('hcdecor_drive_tested_at');
    delete_transient('hcdecor_drive_access_token');
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&disconnected=1')); exit;
});

function hcdecor_drive_access_token($force=false){
    if(!$force){
        $cached=get_transient('hcdecor_drive_access_token');
        if(is_string($cached)&&$cached!==''&&strlen($cached)<=16000) return $cached;
        if($cached!==false) delete_transient('hcdecor_drive_access_token');
    }
    if(!hcdecor_drive_configured()) return new WP_Error('drive_auth','Google Drive chưa kết nối.');
    $r=wp_safe_remote_post('https://oauth2.googleapis.com/token',[
        'timeout'=>25,
        'limit_response_size'=>1024*1024,
        'body'=>[
            'client_id'=>hcdecor_drive_secret('client_id'),
            'client_secret'=>hcdecor_drive_secret('client_secret'),
            'refresh_token'=>hcdecor_drive_secret('refresh_token'),
            'grant_type'=>'refresh_token'
        ]
    ]);
    if(is_wp_error($r)) return $r;
    $code=(int)wp_remote_retrieve_response_code($r);
    $data=json_decode(wp_remote_retrieve_body($r),true);$data=is_array($data)?$data:[];
    $access=is_scalar($data['access_token']??'')?sanitize_text_field((string)$data['access_token']):'';
    if($code<200||$code>=300||$access===''||strlen($access)>16000){
        return new WP_Error('drive_token',hcdecor_drive_safe_error((string)($data['error_description']??$data['error']??('Token HTTP '.$code))));
    }
    $ttl=max(60,min(DAY_IN_SECONDS,(int)($data['expires_in']??3600)-120));
    set_transient('hcdecor_drive_access_token',$access,$ttl);
    return $access;
}

function hcdecor_drive_request($method,$url,$args=[]){
    $parts=wp_parse_url((string)$url);
    if(!is_array($parts) || strtolower((string)($parts['scheme']??''))!=='https' || strtolower((string)($parts['host']??''))!=='www.googleapis.com'){
        return new WP_Error('drive_url','Drive request blocked: untrusted API host.');
    }
    $token=hcdecor_drive_access_token();
    if(is_wp_error($token)) return $token;
    $headers=(array)($args['headers']??[]);
    $headers['Authorization']='Bearer '.$token;
    $args['headers']=$headers;
    $args['method']=$method;
    $args['timeout']=$args['timeout']??60;
    $args['limit_response_size']=$args['limit_response_size']??4*1024*1024;
    $r=wp_safe_remote_request($url,$args);
    if(is_wp_error($r)) return $r;
    $code=(int)wp_remote_retrieve_response_code($r);
    if($code===401){
        delete_transient('hcdecor_drive_access_token');
        $token=hcdecor_drive_access_token(true);
        if(is_wp_error($token)) return $token;
        $args['headers']['Authorization']='Bearer '.$token;
        $r=wp_safe_remote_request($url,$args);
        if(is_wp_error($r)) return $r;
        $code=(int)wp_remote_retrieve_response_code($r);
    }
    $body=wp_remote_retrieve_body($r);
    if($code<200||$code>=300){
        $j=json_decode($body,true);
        return new WP_Error('drive_http',hcdecor_drive_safe_error((string)($j['error']['message']??('Drive HTTP '.$code))),['status'=>$code]);
    }
    return ['code'=>$code,'body'=>$body,'headers'=>wp_remote_retrieve_headers($r)];
}

function hcdecor_drive_test(){
    $r=hcdecor_drive_request('GET','https://www.googleapis.com/drive/v3/about?fields=user,storageQuota');
    if(is_wp_error($r)) return $r;
    $d=json_decode($r['body'],true);
    return is_array($d)?$d:new WP_Error('drive_json','Drive response invalid.');
}

function hcdecor_drive_list($folder_id,$limit=100){
    $folder_id=preg_replace('/[^A-Za-z0-9_-]/','',(string)$folder_id);
    if(!$folder_id) return new WP_Error('folder','Invalid folder.');
    $q=rawurlencode("'".$folder_id."' in parents and trashed=false");
    $fields=rawurlencode('files(id,name,mimeType,size,modifiedTime,webViewLink,thumbnailLink,description)');
    $url='https://www.googleapis.com/drive/v3/files?q='.$q.'&pageSize='.max(1,min(1000,(int)$limit)).'&orderBy=modifiedTime%20desc&fields='.$fields;
    $r=hcdecor_drive_request('GET',$url);
    if(is_wp_error($r)) return $r;
    $d=json_decode($r['body'],true);
    return (array)($d['files']??[]);
}

function hcdecor_drive_multipart($file_id,$name,$mime,$bytes,$parent_id=''){
    $boundary='hcdecor_'.wp_generate_password(18,false,false);
    $meta=['name'=>sanitize_file_name($name)];
    if(!$file_id && $parent_id) $meta['parents']=[(string)$parent_id];
    $body="--{$boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".
        wp_json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).
        "\r\n--{$boundary}\r\nContent-Type: {$mime}\r\n\r\n".$bytes."\r\n--{$boundary}--";
    if($file_id){
        $url='https://www.googleapis.com/upload/drive/v3/files/'.rawurlencode($file_id).'?uploadType=multipart&fields=id,name,mimeType,webViewLink,modifiedTime';
        $method='PATCH';
    }else{
        $url='https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink,modifiedTime';
        $method='POST';
    }
    $r=hcdecor_drive_request($method,$url,[
        'headers'=>['Content-Type'=>'multipart/related; boundary='.$boundary],
        'body'=>$body,
        'timeout'=>120
    ]);
    if(is_wp_error($r)) return $r;
    $d=json_decode($r['body'],true);
    return is_array($d)?$d:new WP_Error('drive_json','Upload response invalid.');
}

function hcdecor_drive_save_json($name,$data,$folder_key,$existing_file_id=''){
    $folders=hcdecor_drive_folders();
    $folder=(string)($folders[$folder_key]??'');
    if(!$folder) return new WP_Error('folder','Drive folder not configured: '.$folder_key);
    $bytes=wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
    if(!is_string($bytes) || $bytes==='') return new WP_Error('json','Unable to encode Drive JSON payload.');
    if(strlen($bytes)>4*1024*1024) return new WP_Error('payload_size','Drive JSON payload exceeds 4 MB.');
    return hcdecor_drive_multipart($existing_file_id,$name,'application/json',$bytes,$folder);
}

function hcdecor_drive_upload_attachment($attachment_id,$folder_key='media_input'){
    $attachment_id=(int)$attachment_id;
    if(get_post_type($attachment_id)!=='attachment') return new WP_Error('media','Invalid attachment.');
    $existing=hcdecor_drive_clip(get_post_meta($attachment_id,'hc_drive_file_id',true),300);
    $path=get_attached_file($attachment_id);
    if(!$path||!is_readable($path)) return new WP_Error('file','Attachment file unavailable.');
    $size=@filesize($path);
    if($size===false || $size<=0 || $size>50*1024*1024) return new WP_Error('size','Drive media upload must be between 1 byte and 50 MB.');
    $bytes=file_get_contents($path);
    if($bytes===false || strlen($bytes)!==(int)$size) return new WP_Error('file','Cannot read attachment safely.');
    $folders=hcdecor_drive_folders();
    $folder=(string)($folders[$folder_key]??'');
    if($folder==='' || !array_key_exists($folder_key,$folders)) return new WP_Error('folder','Managed Drive folder is not configured.');
    $name=basename($path);
    $mime=(string)(get_post_mime_type($attachment_id)?:'application/octet-stream');
    $res=hcdecor_drive_multipart($existing,$name,$mime,$bytes,$folder);
    if(!is_wp_error($res)&&!empty($res['id'])){
        update_post_meta($attachment_id,'hc_drive_file_id',sanitize_text_field($res['id']));
        update_post_meta($attachment_id,'hc_drive_url',esc_url_raw($res['webViewLink']??''));
        update_post_meta($attachment_id,'hc_drive_synced_at',current_time('mysql'));
    }
    return $res;
}

function hcdecor_drive_job_data($job_id){
    $job=get_post($job_id);
    if(!$job||$job->post_type!=='hc_content_job') return new WP_Error('job','Invalid job.');
    $project=(int)get_post_meta($job_id,'hc_project_id',true);
    $media_ids_raw=get_post_meta($job_id,'hc_media_ids',true);$media_ids=array_slice(array_values(array_filter(array_unique(array_map('intval',is_array($media_ids_raw)?$media_ids_raw:[])),function($id){return get_post_type($id)==='attachment';})),0,60);
    $media=[];
    foreach($media_ids as $mid){
        $media[]=[
            'wp_id'=>$mid,
            'drive_file_id'=>hcdecor_drive_clip(get_post_meta($mid,'hc_drive_file_id',true),300),
            'drive_url'=>esc_url_raw(hcdecor_drive_clip(get_post_meta($mid,'hc_drive_url',true),2048)),
            'title'=>hcdecor_drive_clip(get_the_title($mid),500),
            'mime'=>hcdecor_drive_clip(get_post_mime_type($mid),200),
            'ai_summary'=>hcdecor_drive_clip(get_post_meta($mid,'hc_ai_summary',true),5000),
            'ai_tags'=>(function($raw){return array_slice(array_values(array_filter(array_map(function($tag){return hcdecor_drive_clip($tag,100);},is_array($raw)?$raw:[]))),0,30);})(get_post_meta($mid,'hc_ai_tags',true)),
            'cover_score'=>(int)get_post_meta($mid,'hc_ai_cover_score',true)
        ];
    }
    $fields=[];
    if(function_exists('hcdecor_ops_fields')){
        $limits=['web_title'=>300,'web_intro'=>2000,'web_body'=>50000,'seo_meta'=>2000,'facebook_caption'=>10000,'tiktok_script'=>20000,'youtube_title'=>300,'youtube_description'=>20000];
        foreach(hcdecor_ops_fields() as $k) $fields[$k]=hcdecor_drive_clip(get_post_meta($job_id,'hc_'.$k,true),(int)($limits[$k]??10000));
    }
    return [
        'schema'=>'hcdecor.content-job.v1',
        'saved_at'=>current_time('mysql'),
        'source_job_id'=>(int)$job_id,
        'project'=>[
            'wp_id'=>$project,
            'title'=>$project?hcdecor_drive_clip(get_the_title($project),500):'',
            'url'=>$project?get_permalink($project):''
        ],
        'job'=>[
            'title'=>hcdecor_drive_clip($job->post_title,500),
            'brief'=>hcdecor_drive_clip($job->post_content,20000),
            'status'=>sanitize_key(hcdecor_drive_clip(get_post_meta($job_id,'hc_agent_status',true),50)),
            'channels'=>(function($raw){return array_values(array_intersect(['web','facebook','tiktok','youtube'],is_array($raw)?$raw:[]));})(get_post_meta($job_id,'hc_channels',true)),
            'cover_id'=>(int)get_post_meta($job_id,'hc_cover_id',true),
            'ai_provider'=>sanitize_key(hcdecor_drive_clip(get_post_meta($job_id,'hc_ai_provider',true),50)),
            'ai_model'=>hcdecor_drive_clip(get_post_meta($job_id,'hc_ai_model',true),200)
        ],
        'content'=>$fields,
        'media'=>$media,
        'workflow_log'=>hcdecor_drive_job_log(get_post_meta($job_id,'hc_workflow_log',true))
    ];
}

function hcdecor_drive_stage_folder_key($status){
    $map=[
        'draft'=>'content_draft','processing'=>'content_draft','failed'=>'content_draft',
        'review'=>'content_review','approved'=>'content_approved','published_web'=>'content_published'
    ];
    return $map[$status]??'content_draft';
}

function hcdecor_drive_save_job($job_id,$sync_media=true){
    $data=hcdecor_drive_job_data($job_id);
    if(is_wp_error($data)) return $data;
    if($sync_media){
        $sync_media_raw=get_post_meta($job_id,'hc_media_ids',true);foreach(array_slice(is_array($sync_media_raw)?$sync_media_raw:[],0,60) as $mid){
            $mid=(int)$mid;
            if($mid && hcdecor_drive_clip(get_post_meta($mid,'hc_drive_file_id',true),300)==='') hcdecor_drive_upload_attachment($mid,'media_input');
        }
        $data=hcdecor_drive_job_data($job_id);
    }
    $status=sanitize_key(hcdecor_drive_clip(get_post_meta($job_id,'hc_agent_status',true),50));
    $folder_key=hcdecor_drive_stage_folder_key($status);
    $slug=sanitize_file_name('JOB-'.$job_id.'-'.($data['project']['title']?:'content').'.json');
    $meta_key='hc_drive_job_file_'.$folder_key;
    $existing=hcdecor_drive_clip(get_post_meta($job_id,$meta_key,true),300);
    $res=hcdecor_drive_save_json($slug,$data,$folder_key,$existing);
    if(!is_wp_error($res)&&!empty($res['id'])){
        update_post_meta($job_id,$meta_key,sanitize_text_field($res['id']));
        update_post_meta($job_id,'hc_drive_job_file_id',sanitize_text_field($res['id']));
        update_post_meta($job_id,'hc_drive_job_url',esc_url_raw($res['webViewLink']??''));
        update_post_meta($job_id,'hc_drive_synced_at',current_time('mysql'));
        delete_post_meta($job_id,'hc_drive_error');
    }elseif(is_wp_error($res)){
        update_post_meta($job_id,'hc_drive_error',hcdecor_drive_safe_error($res->get_error_message()));
    }
    return $res;
}


function hcdecor_drive_file_meta($file_id){
    $file_id=preg_replace('/[^A-Za-z0-9_-]/','',(string)$file_id);
    if(!$file_id) return new WP_Error('file','Invalid Drive file ID.');
    $fields=rawurlencode('id,name,mimeType,size,modifiedTime,webViewLink,thumbnailLink,description,parents');
    $r=hcdecor_drive_request('GET','https://www.googleapis.com/drive/v3/files/'.rawurlencode($file_id).'?fields='.$fields);
    if(is_wp_error($r)) return $r;
    $d=json_decode($r['body'],true);
    return is_array($d)?$d:new WP_Error('drive_json','Drive metadata invalid.');
}

function hcdecor_drive_file_in_managed_folders($meta,$allowed_keys){
    if(!is_array($meta)) return false;
    $parents=array_values(array_filter(array_map('strval',(array)($meta['parents']??[]))));
    if(!$parents) return false;
    $folders=hcdecor_drive_folders();
    foreach((array)$allowed_keys as $key){ $id=(string)($folders[$key]??''); if($id!=='' && in_array($id,$parents,true)) return true; }
    return false;
}

function hcdecor_drive_import_media($file_id){
    $meta=hcdecor_drive_file_meta($file_id);
    if(is_wp_error($meta)) return $meta;
    if(!hcdecor_drive_file_in_managed_folders($meta,['media_input','media_ai','media_approved'])) return new WP_Error('scope','Drive media file is outside managed HCDecor folders.');
    $mime=(string)($meta['mimeType']??'');
    $size=(int)($meta['size']??0);
    if($size<=0 || $size>50*1024*1024) return new WP_Error('size','Drive media file must be between 1 byte and 50 MB.');
    if(strpos($mime,'image/')!==0 && strpos($mime,'video/')!==0){
        return new WP_Error('mime','Chỉ import image/video từ Drive.');
    }
    $existing=get_posts([
        'post_type'=>'attachment','post_status'=>'inherit','numberposts'=>1,
        'meta_key'=>'hc_drive_file_id','meta_value'=>(string)$meta['id']
    ]);
    if($existing) return (int)$existing[0]->ID;

    $bytes=hcdecor_drive_download($file_id,50*1024*1024);
    if(is_wp_error($bytes)) return $bytes;
    $name=sanitize_file_name((string)($meta['name']??('drive-'.$file_id)));
    if($name==='') $name='drive-'.$file_id;

    $upload=wp_upload_bits($name,null,$bytes);
    if(!empty($upload['error'])) return new WP_Error('upload',(string)$upload['error']);

    require_once ABSPATH.'wp-admin/includes/image.php';
    require_once ABSPATH.'wp-admin/includes/file.php';
    require_once ABSPATH.'wp-admin/includes/media.php';

    $id=wp_insert_attachment([
        'post_mime_type'=>$mime,
        'post_title'=>sanitize_text_field(pathinfo($name,PATHINFO_FILENAME)),
        'post_status'=>'inherit'
    ],$upload['file']);
    if(is_wp_error($id)) return $id;

    $attachment_meta=wp_generate_attachment_metadata($id,$upload['file']);
    if($attachment_meta) wp_update_attachment_metadata($id,$attachment_meta);
    update_post_meta($id,'hc_drive_file_id',sanitize_text_field((string)$meta['id']));
    update_post_meta($id,'hc_drive_url',esc_url_raw((string)($meta['webViewLink']??'')));
    update_post_meta($id,'hc_drive_synced_at',current_time('mysql'));
    return (int)$id;
}

function hcdecor_drive_load_prompt($file_id){
    $meta=hcdecor_drive_file_meta($file_id);
    if(is_wp_error($meta)) return $meta;
    if(!hcdecor_drive_file_in_managed_folders($meta,['prompts'])) return new WP_Error('scope','Drive prompt file is outside the managed prompts folder.');
    $mime=strtolower((string)($meta['mimeType']??''));
    if(!in_array($mime,['application/json','text/json','text/plain'],true)) return new WP_Error('mime','Drive prompt import requires a JSON file.');
    $size=(int)($meta['size']??0);
    if($size<=0 || $size>1024*1024) return new WP_Error('size','Drive prompt file must be between 1 byte and 1 MB.');
    $body=hcdecor_drive_download($file_id);
    if(is_wp_error($body)) return $body;
    $d=json_decode($body,true);
    if(!is_array($d)||($d['schema']??'')!=='hcdecor.prompt.v1') return new WP_Error('schema','Invalid HCDecor prompt file.');
    $prompt=wp_kses_post((string)($d['prompt']??''));
    $prompt=function_exists('mb_substr')?mb_substr($prompt,0,20000):substr($prompt,0,20000);
    if($prompt==='') return new WP_Error('prompt','Prompt is empty.');
    $title=sanitize_text_field((string)($d['title']??''));
    $title=function_exists('mb_substr')?mb_substr($title,0,300):substr($title,0,300);
    update_option('hcdecor_drive_active_prompt',$prompt,false);
    update_option('hcdecor_drive_active_prompt_title',$title,false);
    update_option('hcdecor_drive_active_prompt_file',sanitize_text_field($file_id),false);
    update_option('hcdecor_drive_active_prompt_loaded_at',current_time('mysql'),false);
    return true;
}

function hcdecor_drive_download($file_id,$max_bytes=4194304){
    $file_id=preg_replace('/[^A-Za-z0-9_-]/','',(string)$file_id);
    if(!$file_id) return new WP_Error('file','Invalid Drive file ID.');
    $max_bytes=max(1,min(50*1024*1024,(int)$max_bytes));
    $r=hcdecor_drive_request('GET','https://www.googleapis.com/drive/v3/files/'.rawurlencode($file_id).'?alt=media',['limit_response_size'=>$max_bytes+1]);
    if(is_wp_error($r)) return $r;
    $body=(string)$r['body'];
    if(strlen($body)>$max_bytes) return new WP_Error('size','Drive download exceeds allowed size.');
    return $body;
}

function hcdecor_drive_import_job($file_id){
    $meta=hcdecor_drive_file_meta($file_id);
    if(is_wp_error($meta)) return $meta;
    if(!hcdecor_drive_file_in_managed_folders($meta,['content_draft','content_review','content_approved','content_published'])) return new WP_Error('scope','Drive job file is outside managed content folders.');
    $mime=strtolower((string)($meta['mimeType']??''));
    if(!in_array($mime,['application/json','text/json','text/plain'],true)) return new WP_Error('mime','Drive job import requires a JSON file.');
    $size=(int)($meta['size']??0);
    if($size<=0 || $size>2*1024*1024) return new WP_Error('size','Drive job file must be between 1 byte and 2 MB.');
    $body=hcdecor_drive_download($file_id);
    if(is_wp_error($body)) return $body;
    $d=json_decode($body,true);
    if(!is_array($d)||($d['schema']??'')!=='hcdecor.content-job.v1') return new WP_Error('schema','Invalid HCDecor content job file.');
    $source=(int)($d['source_job_id']??0);
    $id=0;
    if($source && get_post_type($source)==='hc_content_job' && sanitize_key(hcdecor_drive_clip(get_post_meta($source,'hc_agent_status',true),50))==='draft' && hash_equals(hcdecor_drive_clip(get_post_meta($source,'hc_drive_job_file_id',true),300),$file_id)) $id=$source;
    $clip=function($value,$limit){
        $text=sanitize_textarea_field(is_scalar($value)?(string)$value:'');
        return function_exists('mb_substr')?mb_substr($text,0,$limit):substr($text,0,$limit);
    };
    $post=[
        'post_type'=>'hc_content_job','post_status'=>'publish',
        'post_title'=>$clip($d['job']['title']??'Imported Drive Job',300),
        'post_content'=>$clip($d['job']['brief']??'',20000)
    ];
    if($id){$post['ID']=$id;$r=wp_update_post($post,true);}else{$r=wp_insert_post($post,true);}
    if(is_wp_error($r)) return $r;
    $id=(int)$r;
    $project_id=(int)($d['project']['wp_id']??0);
    if($project_id && get_post_type($project_id)==='hc_project') update_post_meta($id,'hc_project_id',$project_id);
    if(function_exists('hcdecor_workflow_set_status')){
        if(!hcdecor_workflow_set_status($id,'draft','Imported from Drive for review')) return new WP_Error('status','Imported job could not enter draft workflow.');
    }else update_post_meta($id,'hc_agent_status','draft');
    $channels=array_values(array_intersect(['web','facebook','tiktok','youtube'],array_map('sanitize_key',(array)($d['job']['channels']??[]))));
    update_post_meta($id,'hc_channels',$channels);
    if(function_exists('hcdecor_ops_save_fields')) hcdecor_ops_save_fields($id,(array)($d['content']??[]));
    update_post_meta($id,'hc_drive_job_file_id',$file_id);
    update_post_meta($id,'hc_drive_loaded_at',current_time('mysql'));
    return $id;
}

function hcdecor_drive_save_prompt($title,$prompt,$existing=''){
    $title=sanitize_text_field((string)$title);
    $title=function_exists('mb_substr')?mb_substr($title,0,300):substr($title,0,300);
    $prompt=wp_kses_post((string)$prompt);
    $prompt=function_exists('mb_substr')?mb_substr($prompt,0,20000):substr($prompt,0,20000);
    $data=[
        'schema'=>'hcdecor.prompt.v1',
        'title'=>$title,
        'prompt'=>$prompt,
        'saved_at'=>current_time('mysql')
    ];
    return hcdecor_drive_save_json(sanitize_file_name($title?:'Prompt').'.json',$data,'prompts',$existing);
}

function hcdecor_drive_workflow_auto_sync_enabled(){
    return (bool)get_option('hcdecor_drive_workflow_auto_sync_enabled',false);
}

add_action('hcdecor_workflow_status_changed',function($job_id,$old,$status){
    if(!hcdecor_drive_workflow_auto_sync_enabled() || !hcdecor_drive_configured()) return;
    if(in_array($status,['review','approved','published_web'],true)) hcdecor_drive_save_job((int)$job_id,$status==='review');
},20,3);

add_action('hcdecor_after_ai_content_generated',function($job_id){
    if(hcdecor_drive_workflow_auto_sync_enabled() && hcdecor_drive_configured()) hcdecor_drive_save_job((int)$job_id,true);
},20,1);

add_action('hcdecor_after_web_publish',function($job_id,$project_id){
    if(!hcdecor_drive_workflow_auto_sync_enabled() || !hcdecor_drive_configured()) return;
    hcdecor_drive_save_job((int)$job_id,false);
    hcdecor_drive_save_json('PUBLISH-'.$project_id.'-'.gmdate('Ymd-His').'.json',[
        'schema'=>'hcdecor.publish.v1','job_id'=>(int)$job_id,'project_id'=>(int)$project_id,
        'url'=>get_permalink($project_id),'published_at'=>current_time('mysql')
    ],'manifests');
},30,2);

add_action('admin_menu',function(){
    add_submenu_page('hcdecor-hub','Drive Vault','Drive Vault','manage_options','hcdecor-drive-vault','hcdecor_drive_vault_page',6);
},29);


add_action('admin_post_hcdecor_drive_save_connect',function(){
    if(!current_user_can('manage_options')) wp_die('Forbidden');
    check_admin_referer('hcdecor_drive_save_connect');
    $client_raw=wp_unslash($_POST['client_id']??'');$client_id=is_scalar($client_raw)?trim((string)$client_raw):'';
    $secret_raw=wp_unslash($_POST['client_secret']??'');$client_secret=is_scalar($secret_raw)?trim((string)$secret_raw):'';
    if(strlen($client_id)>1000 || strlen($client_secret)>4000) wp_die('Credential value too long.');
    $auth_changed=false;
    if($client_id!=='' && $client_id!==hcdecor_drive_clip(get_option('hcdecor_drive_client_id',''),1000)){ update_option('hcdecor_drive_client_id',$client_id,false); $auth_changed=true; }
    if($client_secret!=='' && $client_secret!==hcdecor_drive_clip(get_option('hcdecor_drive_client_secret',''),4000)){ update_option('hcdecor_drive_client_secret',$client_secret,false); $auth_changed=true; }
    if($auth_changed){
        delete_transient('hcdecor_drive_access_token');
        delete_option('hcdecor_drive_test_status');
        delete_option('hcdecor_drive_test_message');
        delete_option('hcdecor_drive_tested_at');
    }
    if(hcdecor_drive_secret('client_id')==='' || hcdecor_drive_secret('client_secret')===''){
        wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&oauth_missing=1')); exit;
    }
    wp_redirect(hcdecor_drive_oauth_connect_url()); exit;
});

add_action('admin_post_hcdecor_drive_settings',function(){
    if(!current_user_can('manage_options')) wp_die('Forbidden');
    check_admin_referer('hcdecor_drive_settings');
    $auth_changed=false;
    $credential_limits=['client_id'=>1000,'client_secret'=>4000,'refresh_token'=>8000];
    foreach($credential_limits as $k=>$limit){
        $raw=wp_unslash($_POST[$k]??'');$v=is_scalar($raw)?trim((string)$raw):'';
        if(strlen($v)>$limit) wp_die('Credential value too long.');
        if($v!=='' && $v!==hcdecor_drive_clip(get_option('hcdecor_drive_'.$k,''),$limit)){ update_option('hcdecor_drive_'.$k,$v,false); $auth_changed=true; }
    }
    if(!empty($_POST['clear_auth'])){
        foreach(['client_id','client_secret','refresh_token'] as $k) delete_option('hcdecor_drive_'.$k);
        delete_transient('hcdecor_drive_access_token');
        $auth_changed=true;
    }
    if($auth_changed){
        delete_transient('hcdecor_drive_access_token');
        delete_option('hcdecor_drive_test_status');
        delete_option('hcdecor_drive_test_message');
        delete_option('hcdecor_drive_tested_at');
    }
    update_option('hcdecor_drive_workflow_auto_sync_enabled',!empty($_POST['workflow_auto_sync']),false);
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&saved=1'));exit;
});

add_action('admin_post_hcdecor_drive_test',function(){
    if(!current_user_can('manage_options')) wp_die('Forbidden');
    check_admin_referer('hcdecor_drive_test');
    $r=hcdecor_drive_test();
    if(is_wp_error($r)){
        update_option('hcdecor_drive_test_status','error',false);
        update_option('hcdecor_drive_test_message',hcdecor_drive_safe_error($r->get_error_message()),false);
    }else{
        update_option('hcdecor_drive_test_status','ok',false);
        update_option('hcdecor_drive_test_message',(string)($r['user']['emailAddress']??'Connected'),false);
    }
    update_option('hcdecor_drive_tested_at',time(),false);
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&tested=1'));exit;
});

add_action('admin_post_hcdecor_drive_save_job',function(){
    if(!current_user_can('edit_posts')) wp_die('Forbidden');
    $job_raw=$_POST['job_id']??0;$id=is_scalar($job_raw)?(int)$job_raw:0;check_admin_referer('hcdecor_drive_save_job_'.$id);
    if(get_post_type($id)!=='hc_content_job' || !current_user_can('edit_post',$id)) wp_die('Invalid job');
    $r=hcdecor_drive_save_job($id,true);
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&job='.$id.(is_wp_error($r)?'&drive_error=1':'&drive_saved=1')));exit;
});

add_action('admin_post_hcdecor_drive_import_job',function(){
    if(!current_user_can('edit_posts')) wp_die('Forbidden');
    check_admin_referer('hcdecor_drive_import_job');
    $file_raw=wp_unslash($_POST['file_id']??'');$file=preg_replace('/[^A-Za-z0-9_-]/','',is_scalar($file_raw)?(string)$file_raw:'');
    if($file==='') wp_die('Invalid Drive file ID.');
    $r=hcdecor_drive_import_job($file);
    if(is_wp_error($r)) wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&import_error=1'));
    else wp_safe_redirect(admin_url('admin.php?page=hcdecor-content-operations&job='.(int)$r.'&drive_loaded=1'));
    exit;
});


add_action('admin_post_hcdecor_drive_import_media',function(){
    if(!current_user_can('upload_files')) wp_die('Forbidden');
    $file_raw=wp_unslash($_POST['file_id']??'');$file=preg_replace('/[^A-Za-z0-9_-]/','',is_scalar($file_raw)?(string)$file_raw:'');
    if($file==='') wp_die('Invalid Drive file ID.');
    $folder_raw=$_POST['folder_key']??'media_input';$folder=sanitize_key(is_scalar($folder_raw)?(string)$folder_raw:'media_input');
    check_admin_referer('hcdecor_drive_import_media_'.$file);
    $r=hcdecor_drive_import_media($file);
    $url=admin_url('admin.php?page=hcdecor-drive-vault&browse='.$folder);
    $url=add_query_arg(is_wp_error($r)?['media_import_error'=>1]:['media_imported'=>(int)$r],$url);
    wp_safe_redirect($url); exit;
});

add_action('admin_post_hcdecor_drive_activate_prompt',function(){
    if(!current_user_can('manage_options')) wp_die('Forbidden');
    $file_raw=wp_unslash($_POST['file_id']??'');$file=preg_replace('/[^A-Za-z0-9_-]/','',is_scalar($file_raw)?(string)$file_raw:'');
    if($file==='') wp_die('Invalid Drive file ID.');
    check_admin_referer('hcdecor_drive_activate_prompt_'.$file);
    $r=hcdecor_drive_load_prompt($file);
    $url=admin_url('admin.php?page=hcdecor-drive-vault&browse=prompts');
    $url=add_query_arg(is_wp_error($r)?['prompt_load_error'=>1]:['prompt_active'=>1],$url);
    wp_safe_redirect($url); exit;
});

add_action('admin_post_hcdecor_drive_save_prompt',function(){
    if(!current_user_can('manage_options')) wp_die('Forbidden');
    check_admin_referer('hcdecor_drive_save_prompt');
    $title_raw=wp_unslash($_POST['prompt_title']??'');$title=sanitize_text_field(is_scalar($title_raw)?(string)$title_raw:'');
    $prompt_raw=wp_unslash($_POST['prompt']??'');$prompt=is_scalar($prompt_raw)?(string)$prompt_raw:'';
    $r=hcdecor_drive_save_prompt($title,$prompt);
    if(!is_wp_error($r)){
        $active=wp_kses_post((string)$prompt);
        $active=function_exists('mb_substr')?mb_substr($active,0,20000):substr($active,0,20000);
        update_option('hcdecor_drive_active_prompt',$active,false);
        $active_title=sanitize_text_field((string)$title);
        $active_title=function_exists('mb_substr')?mb_substr($active_title,0,300):substr($active_title,0,300);
        update_option('hcdecor_drive_active_prompt_title',$active_title,false);
        update_option('hcdecor_drive_active_prompt_file',sanitize_text_field($r['id']??''),false);
    }
    wp_safe_redirect(admin_url('admin.php?page=hcdecor-drive-vault&prompt_saved='.(is_wp_error($r)?'0':'1')));exit;
});

add_action('rest_api_init',function(){
    register_rest_route('hcdecor/v1','/drive/status',[
        'methods'=>'GET','permission_callback'=>'hcdecor_ops_bridge_auth',
        'callback'=>function(){
            $configured=hcdecor_drive_configured();
            $test_status=hcdecor_drive_clip(get_option('hcdecor_drive_test_status',''),20);
            return rest_ensure_response([
                'configured'=>$configured,
                'live_health'=>$configured?($test_status==='ok'?'test_ok':($test_status==='error'?'test_failed':'untested')):'not_configured',
                'tested_at'=>hcdecor_drive_clip(get_option('hcdecor_drive_tested_at',''),64),
                'managed_folder_count'=>count(hcdecor_drive_folders()),
                'error'=>$test_status==='error'?hcdecor_drive_clip(get_option('hcdecor_drive_test_message',''),500):''
            ]);
        }
    ]);
    register_rest_route('hcdecor/v1','/drive/list/(?P<folder>[A-Za-z0-9_-]+)',[
        'methods'=>'GET','permission_callback'=>'hcdecor_ops_bridge_auth',
        'callback'=>function(WP_REST_Request $r){
            $folder=sanitize_key((string)$r['folder']);$folders=hcdecor_drive_folders();
            if(!isset($folders[$folder])) return new WP_Error('folder','Unknown managed Drive folder',['status'=>400]);
            $id=$folders[$folder];
            $limit_raw=$r->get_param('limit');$limit=is_scalar($limit_raw)?(int)$limit_raw:100;$limit=max(1,min(100,$limit));
            $res=hcdecor_drive_list($id,$limit);
            return is_wp_error($res)?$res:rest_ensure_response($res);
        }
    ]);
    register_rest_route('hcdecor/v1','/drive/jobs/(?P<id>\d+)/save',[
        'methods'=>'POST','permission_callback'=>'hcdecor_ops_bridge_auth',
        'callback'=>function(WP_REST_Request $r){
            $id=(int)$r['id'];
            if(!$id || get_post_type($id)!=='hc_content_job') return new WP_Error('job','Invalid content job.',['status'=>404]);
            if(get_current_user_id()>0 && !current_user_can('edit_post',$id)) return new WP_Error('forbidden','Forbidden.',['status'=>403]);
            if(!hcdecor_drive_approval_fresh($r)) return new WP_Error('approval','Fresh explicit approval is required for Drive job writes.',['status'=>403]);
            $res=hcdecor_drive_save_job($id,true);
            return is_wp_error($res)?$res:rest_ensure_response($res);
        }
    ]);
    register_rest_route('hcdecor/v1','/drive/import',[
        'methods'=>'POST','permission_callback'=>'hcdecor_ops_bridge_auth',
        'callback'=>function(WP_REST_Request $r){
            if(!hcdecor_drive_approval_fresh($r)) return new WP_Error('approval','Fresh explicit approval is required for Drive imports.',['status'=>403]);
            $file_raw=$r->get_param('file_id');$file=preg_replace('/[^A-Za-z0-9_-]/','',is_scalar($file_raw)?(string)$file_raw:'');
            if($file==='') return new WP_Error('file','Invalid Drive file ID.',['status'=>400]);
            $res=hcdecor_drive_import_job($file);
            return is_wp_error($res)?$res:rest_ensure_response(['job_id'=>$res]);
        }
    ]);
});

function hcdecor_drive_vault_page(){
    if(!current_user_can('manage_options')) return;
    $folders=hcdecor_drive_folders();
    $status=hcdecor_drive_clip(get_option('hcdecor_drive_test_status',''),20);
    $msg=hcdecor_drive_clip(get_option('hcdecor_drive_test_message',''),500);
    $jobs=get_posts(['post_type'=>'hc_content_job','post_status'=>'publish','numberposts'=>20,'orderby'=>'modified','order'=>'DESC']);
    $prompt_files=hcdecor_drive_configured()?hcdecor_drive_list($folders['prompts'],20):[];
    if(is_wp_error($prompt_files)) $prompt_files=[];
    $browse_allowed=['prompts','media_input','media_ai','media_approved','content_draft','content_review','content_approved','content_published','projects','knowledge','templates','automation','archive'];
    $browse_raw=$_GET['browse']??'media_input';$browse_key=sanitize_key(is_scalar($browse_raw)?(string)$browse_raw:'media_input');
    if(!in_array($browse_key,$browse_allowed,true)) $browse_key='media_input';
    $browse_files=hcdecor_drive_configured()?hcdecor_drive_list($folders[$browse_key]??$folders['root'],60):[];
    if(is_wp_error($browse_files)) $browse_files=[];
    ?>
    <div class="wrap hcdv" style="max-width:1400px">
      <h1>HCDecor Drive Vault</h1>
      <p><strong>Google Drive = DATA Vault</strong> · WordPress = Index / Queue / Workflow.</p>
      <div style="display:grid;grid-template-columns:420px 1fr;gap:14px">
        <section style="background:#fff;border:1px solid #ddd;border-radius:12px;padding:18px">
          <h2>Google Drive Connection</h2>
          <p><strong><?php echo hcdecor_drive_configured()?($status==='ok'?'CONNECTED':'CONFIGURED'):'NOT CONNECTED';?></strong><?php if($msg):?> · <?php echo esc_html($msg);?><?php endif;?></p>

          <div style="background:#f6f7f7;border:1px solid #dcdcde;border-radius:10px;padding:12px;margin:12px 0">
            <strong>Bước 1 · Google OAuth</strong>
            <p style="margin:6px 0 0">Tạo OAuth Client kiểu <strong>Web application</strong> và thêm Redirect URI này:</p>
            <code style="display:block;word-break:break-all;margin-top:6px"><?php echo esc_html(hcdecor_drive_oauth_redirect_uri());?></code>
          </div>

          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>">
            <input type="hidden" name="action" value="hcdecor_drive_save_connect"><?php wp_nonce_field('hcdecor_drive_save_connect');?>
            <p><label><strong>OAuth Client ID</strong></label><input class="widefat" type="password" name="client_id" autocomplete="new-password" placeholder="<?php echo hcdecor_drive_secret('client_id')?'Đã lưu · nhập mới để thay':'Dán Client ID';?>"></p>
            <p><label><strong>OAuth Client Secret</strong></label><input class="widefat" type="password" name="client_secret" autocomplete="new-password" placeholder="<?php echo hcdecor_drive_secret('client_secret')?'Đã lưu · nhập mới để thay':'Dán Client Secret';?>"></p>
            <p><button class="button button-primary">Lưu & Connect Google Drive</button></p>
          </form>

          <?php if(hcdecor_drive_secret('refresh_token')!==''):?>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>">
              <input type="hidden" name="action" value="hcdecor_drive_test"><?php wp_nonce_field('hcdecor_drive_test');?>
              <button class="button">Test Drive</button>
            </form>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>">
              <input type="hidden" name="action" value="hcdecor_drive_disconnect"><?php wp_nonce_field('hcdecor_drive_disconnect');?>
              <button class="button">Disconnect</button>
            </form>
          </div>
          <?php endif;?>

          <details style="margin-top:12px"><summary>Advanced / Manual token</summary>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" style="margin-top:10px">
              <input type="hidden" name="action" value="hcdecor_drive_settings"><?php wp_nonce_field('hcdecor_drive_settings');?>
              <p><label>Refresh Token</label><input class="widefat" type="password" name="refresh_token" autocomplete="new-password" placeholder="<?php echo hcdecor_drive_secret('refresh_token')?'Đã lưu · nhập mới để thay':'Manual only';?>"></p>
              <p><label><input type="checkbox" name="workflow_auto_sync" value="1" <?php checked(hcdecor_drive_workflow_auto_sync_enabled());?>> Tự động lưu workflow/AI/publish artifacts vào Drive</label><br><small>Mặc định OFF. Các nút Save/Import thủ công vẫn hoạt động khi tùy chọn này tắt.</small></p>
              <p><button class="button">Lưu cài đặt Drive</button> <label><input type="checkbox" name="clear_auth" value="1"> Xóa auth</label></p>
            </form>
          </details>

          <?php $connected_email=hcdecor_drive_clip(get_option('hcdecor_drive_connected_email',''),320); if($connected_email):?><p><strong>Google account:</strong> <?php echo esc_html($connected_email);?></p><?php endif;?>
          <hr><p><strong>Root Vault</strong><br><code><?php echo esc_html($folders['root']);?></code></p>
          <p><a class="button" target="_blank" rel="noopener" href="<?php echo esc_url('https://drive.google.com/drive/folders/'.$folders['root']);?>">Open Google Drive Vault</a></p>
          <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=hcdecor-drive-inbox'));?>">Drive Inbox Automation</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=hcdecor-project-vault'));?>">Project Vault</a></p>
        </section>
        <section>
          <div style="background:#fff;border:1px solid #ddd;border-radius:12px;padding:18px;margin-bottom:14px">
            <h2>Prompt → Media → Content → Review → Publish → Archive</h2>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
            <?php foreach(['prompts'=>'Prompt Vault','media_input'=>'Media Input','content_review'=>'Review','content_approved'=>'Approved','content_published'=>'Published','archive'=>'Archive'] as $k=>$label):?>
              <a class="button" target="_blank" rel="noopener" href="<?php echo esc_url('https://drive.google.com/drive/folders/'.$folders[$k]);?>"><?php echo esc_html($label);?></a>
            <?php endforeach;?>
            </div>
          </div>
          <div style="background:#fff;border:1px solid #ddd;border-radius:12px;padding:18px;margin-bottom:14px">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap">
              <div><h2 style="margin:0 0 4px">Drive Browser</h2><span>Browse & Load trực tiếp, không cần copy File ID.</span></div>
              <form method="get" action="<?php echo esc_url(admin_url('admin.php'));?>">
                <input type="hidden" name="page" value="hcdecor-drive-vault">
                <select name="browse" onchange="this.form.submit()">
                <?php foreach([
                  'prompts'=>'Prompt Vault','media_input'=>'Media Input','media_ai'=>'AI Media','media_approved'=>'Approved Media',
                  'content_draft'=>'Content Draft','content_review'=>'Content Review','content_approved'=>'Content Approved',
                  'content_published'=>'Content Published','projects'=>'Projects','knowledge'=>'Knowledge','templates'=>'Templates',
                  'automation'=>'Automation','archive'=>'Archive'
                ] as $k=>$label):?>
                  <option value="<?php echo esc_attr($k);?>" <?php selected($browse_key,$k);?>><?php echo esc_html($label);?></option>
                <?php endforeach;?>
                </select>
              </form>
            </div>
            <?php if(!hcdecor_drive_configured()):?>
              <p style="margin-top:14px"><strong>Kết nối Google Drive để bật Browser.</strong></p>
            <?php elseif(!$browse_files):?>
              <p style="margin-top:14px">Folder hiện chưa có file.</p>
            <?php else:?>
              <div style="margin-top:12px;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px">
              <?php foreach($browse_files as $df): $mime=(string)($df['mimeType']??''); $fid=(string)($df['id']??''); $name=(string)($df['name']??''); ?>
                <div style="border:1px solid #e5e5e5;border-radius:10px;padding:12px;min-width:0">
                  <strong style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo esc_html($name);?></strong>
                  <small style="display:block;color:#646970;margin:4px 0 8px"><?php echo esc_html($mime);?></small>
                  <div style="display:flex;gap:6px;flex-wrap:wrap">
                    <?php if(!empty($df['webViewLink'])):?><a class="button button-small" target="_blank" rel="noopener" href="<?php echo esc_url($df['webViewLink']);?>">Open</a><?php endif;?>
                    <?php if($browse_key==='prompts' && substr($name,-5)==='.json'):?>
                      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>">
                        <input type="hidden" name="action" value="hcdecor_drive_activate_prompt"><input type="hidden" name="file_id" value="<?php echo esc_attr($fid);?>"><?php wp_nonce_field('hcdecor_drive_activate_prompt_'.$fid);?>
                        <button class="button button-small">Use Prompt</button>
                      </form>
                    <?php elseif(strpos($mime,'image/')===0 || strpos($mime,'video/')===0):?>
                      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>">
                        <input type="hidden" name="action" value="hcdecor_drive_import_media"><input type="hidden" name="file_id" value="<?php echo esc_attr($fid);?>"><input type="hidden" name="folder_key" value="<?php echo esc_attr($browse_key);?>"><?php wp_nonce_field('hcdecor_drive_import_media_'.$fid);?>
                        <button class="button button-small">Import Media</button>
                      </form>
                    <?php elseif(substr($name,-5)==='.json' && strpos($browse_key,'content_')===0):?>
                      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>">
                        <input type="hidden" name="action" value="hcdecor_drive_import_job"><input type="hidden" name="file_id" value="<?php echo esc_attr($fid);?>"><?php wp_nonce_field('hcdecor_drive_import_job');?>
                        <button class="button button-small">Load Job</button>
                      </form>
                    <?php endif;?>
                  </div>
                </div>
              <?php endforeach;?>
              </div>
            <?php endif;?>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div style="background:#fff;border:1px solid #ddd;border-radius:12px;padding:18px">
              <h2>Prompt Vault</h2>
              <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>">
                <input type="hidden" name="action" value="hcdecor_drive_save_prompt"><?php wp_nonce_field('hcdecor_drive_save_prompt');?>
                <p><input class="widefat" type="text" name="prompt_title" placeholder="Tên prompt" required></p>
                <p><textarea class="widefat" name="prompt" rows="8" placeholder="Prompt / SOP / instruction..." required><?php echo esc_textarea(get_option('hcdecor_drive_active_prompt',''));?></textarea></p>
                <button class="button button-primary">Save Prompt → Drive</button>
              </form>
              <?php if($prompt_files):?><hr><strong>Drive Prompts</strong><ul><?php foreach($prompt_files as $pf):?><li><code><?php echo esc_html($pf['id']);?></code> · <?php echo esc_html($pf['name']);?></li><?php endforeach;?></ul><?php endif;?>
            </div>
            <div style="background:#fff;border:1px solid #ddd;border-radius:12px;padding:18px">
              <h2>Load Content Job</h2>
              <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>">
                <input type="hidden" name="action" value="hcdecor_drive_import_job"><?php wp_nonce_field('hcdecor_drive_import_job');?>
                <p><input class="widefat" type="text" name="file_id" placeholder="Google Drive JSON File ID" required></p>
                <button class="button">Load Drive → HUB</button>
              </form>
              <hr><h3>Recent Jobs</h3>
              <?php foreach($jobs as $j):?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" style="display:flex;justify-content:space-between;gap:8px;border-top:1px solid #eee;padding:8px 0">
                  <span>#<?php echo $j->ID;?> <?php echo esc_html($j->post_title);?></span>
                  <input type="hidden" name="action" value="hcdecor_drive_save_job"><input type="hidden" name="job_id" value="<?php echo $j->ID;?>"><?php wp_nonce_field('hcdecor_drive_save_job_'.$j->ID);?>
                  <button class="button">Save → Drive</button>
                </form>
              <?php endforeach;?>
            </div>
          </div>
        </section>
      </div>
    </div><?php
}
